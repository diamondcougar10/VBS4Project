// make sure to adjust the script paths used below (\vbs2\KRON\MY_CommandMenu\...)
// to match the location of your addon folder


class CfgPatches {
	class MY_CommandMenu {
		units[]={};
		weapons[]={};
		requiredVersion=1.0;
	};
};

// definition of main custom menu
class MY_CustomMenu {
	access=0;
	title="Custom Menu";
	atomic=0;
	vocabulary="";
	contexsensitive=1;

	// items in main menu
	class Items {
		// header (just text)
		class Header1 {
			title="Removal options";
			shortcuts[]={};
			command=-2;
			show="1";
			enable="1";
			speechId=0;
		};
		// selectable action (always visible & active)
		class RemoveAll {
			title=" Remove all";
			shortcuts[]={2};
			show="1";
			enable="1";
			command=-5;
			eventHandler="['remove','all'] execVM '\vbs2\KRON\MY_CommandMenu\data\scripts\place.sqf'";
			speechId=0;
		};
		// selectable action (only visible & active if cursor is pointed at group member)
		class RemoveUnit {
			title=" Remove unit";
			shortcuts[]={3};
			show="CursorOnGroupMember";
			enable="CursorOnGroupMember";
			command=-5;
			eventHandler="['remove','unit'] execVM '\vbs2\KRON\MY_CommandMenu\data\scripts\place.sqf'";
			speechId=0;
		};
		class RemoveVehicle {
			title=" Remove vehicle";
			shortcuts[]={4};
			show="CursorOnEmptyVehicle";
			enable="CursorOnEmptyVehicle";
			command=-5;
			eventHandler="['remove','vehicle'] execVM '\vbs2\KRON\MY_CommandMenu\data\scripts\place.sqf'";
			speechId=0;
		};

		// separator line
		class Separator {
			title="";
			shortcuts[]={};
			command=-1;
			show="1";
			enable="1";
			speechId=0;
		};
		class Header2 {
			title="Placement options";
			shortcuts[]={};
			command=-2;
			show="1";
			enable="1";
			speechId=0;
		};

		// action to bring up the submenu 'MY_CustomMenu_PlaceUnit'
		class PlaceUnit {
			title=" Place unit";
			shortcuts[]={4};
			show="1";
			enable="CursorOnGround * 1-CursorOnGroupMember * 1-CursorOnEmptyVehicle";
			menu="MY_CustomMenu_PlaceUnit";
			speechId=0;
		};
		class PlaceVehicle {
			title=" Place vehicle";
			shortcuts[]={5};
			show="1";
			enable="CursorOnGround * 1-CursorOnGroupMember * 1-CursorOnEmptyVehicle";
			menu="MY_CustomMenu_PlaceVeh";
			speechId=0;
		};

	};
};

// submenu to place units
class MY_CustomMenu_PlaceUnit {
	access=0;
	title="";
	atomic=0;
	vocabulary="";
	contexsensitive=1;

	class Items {
		class Header1 {
			title="Type of unit to place";
			shortcuts[]={};
			command=-2;
			show="1";
			enable="1";
			speechId=0;
		};
		class PlaceUnarmed {
			title=" Unarmed";
			shortcuts[]={2};
			show="1";
			enable="CursorOnGround * 1-CursorOnGroupMember * 1-CursorOnEmptyVehicle";
			command=-5;
			eventHandler="['place','unit','VBS2_US_ARMY_Interpreter_W'] execVM '\vbs2\KRON\MY_CommandMenu\data\scripts\place.sqf'";
			speechId=0;
		};
		class PlaceMG {
			title=" Machinegun";
			shortcuts[]={3};
			show="1";
			enable="CursorOnGround * 1-CursorOnGroupMember * 1-CursorOnEmptyVehicle";
			command=-5
			eventHandler="['place','unit','VBS2_US_ARMY_MGunner_W_M249_none'] execVM '\vbs2\KRON\MY_CommandMenu\data\scripts\place.sqf'";
			speechId=0;
		};
		class PlaceAT {
			title=" Anti-Tank";
			shortcuts[]={4};
			show="1";
			enable="CursorOnGround * 1-CursorOnGroupMember * 1-CursorOnEmptyVehicle";
			command=-5;
			eventHandler="['place','unit','VBS2_us_army_ATsoldier_W_Javelin_none'] execVM '\vbs2\KRON\MY_CommandMenu\data\scripts\place.sqf'";
			speechId=0;
		};				
	};
};

// submenu to place vehicles
class MY_CustomMenu_PlaceVeh {
	access=0;
	title="";
	atomic=0;
	vocabulary="";
	contexsensitive=1;

	class Items {
		class Header1 {
			title="Type of veh. to place";
			shortcuts[]={};
			command=-2;
			show="1";
			enable="1";
			speechId=0;
		};
		class PlaceUnarmed {
			title=" Land Rover";
			shortcuts[]={2};
			show="1";
			enable="CursorOnGround * 1-CursorOnGroupMember * 1-CursorOnEmptyVehicle";
			command=-5;
			eventHandler="['place','vehicle','VBS2_AU_Army_Landrover_D_X'] execVM '\vbs2\KRON\MY_CommandMenu\data\scripts\place.sqf'";
			speechId=0;
		};
		class PlaceMG {
			title=" Humvee";
			shortcuts[]={3};
			show="1";
			enable="CursorOnGround * 1-CursorOnGroupMember * 1-CursorOnEmptyVehicle";
			command=-5
			eventHandler="['place','vehicle','VBS2_US_ARMY_M1114_D_X'] execVM '\vbs2\KRON\MY_CommandMenu\data\scripts\place.sqf'";
			speechId=0;
		};
		class PlaceAT {
			title=" Abrams";
			shortcuts[]={4};
			show="1";
			enable="CursorOnGround * 1-CursorOnGroupMember * 1-CursorOnEmptyVehicle";
			command=-5;
			eventHandler="['place','vehicle','VBS2_US_ARMY_M1A1_D_X'] execVM '\vbs2\KRON\MY_CommandMenu\data\scripts\place.sqf'";
			speechId=0;
		};				
	};
};
