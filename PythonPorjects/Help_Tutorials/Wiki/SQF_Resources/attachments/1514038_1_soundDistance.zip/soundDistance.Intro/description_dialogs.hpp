/*==================================================================
This file sets up standard dialog control base classes and defines,
using the default VBS2 color / font theme

Include it at the top of description.ext's using this line:

	#include "description_dialogs.hpp"

==================================================================*/


//---------------------------------
// Common defines
//---------------------------------

#define true 1
#define false 0

#define ReadAndWrite 0 //! any modifications enabled
#define ReadAndCreate 1 //! only adding new class members is allowed
#define ReadOnly 2 //! no modifications enabled
#define ReadOnlyVerified 3 //! no modifications enabled, CRC test applied


//---------------------------------
// Control types
//---------------------------------

//2D controls
#define CT_STATIC           0
#define CT_BUTTON           1
#define CT_EDIT             2
#define CT_SLIDER           3
#define CT_COMBO            4
#define CT_LISTBOX          5
#define CT_TOOLBOX          6
#define CT_CHECKBOXES       7
#define CT_PROGRESS         8
#define CT_HTML             9
#define CT_STATIC_SKEW      10
#define CT_ACTIVETEXT       11
#define CT_TREE             12
#define CT_STRUCTURED_TEXT  13
#define CT_CONTEXT_MENU     14
#define CT_CONTROLS_GROUP   15
#define CT_XKEYDESC         40
#define CT_XBUTTON          41
#define CT_XLISTBOX         42
#define CT_XSLIDER          43
#define CT_XCOMBO           44
#define CT_ANIMATED_TEXTURE 45
#define CT_LINEBREAK        98
#define CT_USER             99
#define CT_MAP              100
#define CT_MAP_MAIN         101

//3D controls
#define CT_OBJECT           80
#define CT_OBJECT_ZOOM      81
#define CT_OBJECT_CONTAINER 82
#define CT_OBJECT_CONT_ANIM 83

//todo: verify these
#define CT_3DSTATIC     20
#define CT_3DACTIVETEXT 21
#define CT_3DLISTBOX    22
#define CT_3DHTML       23
#define CT_3DSLIDER     24
#define CT_3DEDIT       25


//---------------------------------
// Control styles
//---------------------------------

//many of these can be combined; eg: style = ST_RIGHT + ST_SHADOW;

//static styles
#define ST_POS            0x0F
#define ST_HPOS           0x03
#define ST_VPOS           0x0C
#define ST_LEFT           0x00 //left aligned text
#define ST_RIGHT          0x01 //right aligned text
#define ST_CENTER         0x02 //center aligned text
#define ST_DOWN           0x04
#define ST_UP             0x08
#define ST_VCENTER        0x0c

#define ST_TYPE           0xF0
#define ST_SINGLE         0    //single line textbox
#define ST_MULTI          16   //multi-line textbox (text will wrap, and newline character can be used). There is no scrollbar, but mouse wheel/arrows can scroll it. Control will be outlined with a line (color = text color).
#define ST_TITLE_BAR      32
#define ST_PICTURE        48   //turns a static control into a picture control. 'Text' will be used as picture path. Picture will be stretched to fit the control.
#define ST_FRAME          64   //control becomes a frame. Background is clear and text is placed along the top edge of the control. Control is outlined with text color (as in ST_MULTI).
#define ST_BACKGROUND     80
#define ST_GROUP_BOX      96
#define ST_GROUP_BOX2     112
#define ST_HUD_BACKGROUND 128  //control is rounded and outlined (just like a hint box)
#define ST_TILE_PICTURE   144
#define ST_WITH_RECT      160
#define ST_LINE           176  //a line is drawn between the top left and bottom right of the control (color = text color). Background is clear. Control can still have text, however.

#define ST_SHADOW         0x100 //text or image is given a shadow
#define ST_NO_RECT        0x200 //when combined with ST_MULTI, it eliminates the outline around the control. Might combine with other styles for similar effect.
#define ST_KEEP_ASPECT_RATIO  0x800 //used for pictures, it makes the displayed picture keep its aspect ratio.

#define ST_TITLE          ST_TITLE_BAR + ST_CENTER

// Slider styles
#define SL_DIR            0x400
#define SL_VERT           0
#define SL_HORZ           0x400

#define SL_TEXTURES       0x10

// Listbox styles
#define LB_TEXTURES       0x10   //removes all extra lines from listbox, leaving only a gradiant scrollbar. Useful when LB has a painted background behind it.
#define LB_MULTI          0x20   //allows multiple elements of the LB to be selected (by holding shift / ctrl)

// Tree styles
#define TR_SHOWROOT       1
#define TR_AUTOCOLLAPSE   2

// MessageBox styles
#define MB_BUTTON_OK      1
#define MB_BUTTON_CANCEL  2
#define MB_KEY_X          4
#define MB_KEY_Y          8
#define MB_KEY_START      16


//---------------------------------
// Hardcoded IDCs
//---------------------------------

#define IDC_OK            1
#define IDC_CANCEL        2
#define IDC_AUTOCANCEL    3
#define IDC_ABORT         4
#define IDC_RESTART       5


//---------------------------------
// Default control parameters
//---------------------------------

//Default text/font attributes for structured text controls.
class DefaultTextAttributes
{
	font = FontMAIN;
	color = "#ffffff";
	size = 1;
	align = "left";
	valign = "middle";
	shadow = "true";
	shadowOffset = 0.1;
	shadowColor = "#000000";
	underline = "false";
};

//Default sounds for controls.
class DefaultSounds
{
	soundOK[] = {"", 0.1, 1};
	soundCancel[] = {"", 0.1, 1};
	soundChangeFocus[] = {"", 0.1, 1};
	soundFail[] = {"", 0.1, 1};
};


//---------------------------------
// Base classes for controls
//---------------------------------

//Standard static text.
class RscText
{
	idc = -1;
	type = CT_STATIC;
	style = ST_LEFT;
	w = 0.10;
	h = 0.0350;
	colorBackground[] = {0, 0, 0, 0};
	colorBorder[] = {0, 0, 0, 0};
	colorText[] = {1, 1, 1, 1};
	text = "";
	font = "vbs_unicode_lite";
	SizeEx = .0275;
};

//Multi-line text.
class RscTextMulti: RscText
{
	linespacing = 1;
	style = ST_LEFT + ST_MULTI + ST_NO_RECT;
};

//Standard active text (text that can be clicked like a button)
class RscActiveText
{
	idc = -1;
	type = CT_ACTIVETEXT;
	style = ST_CENTER;
	access = 0;
	w = 0.15;
	h = 0.0350;
	color[] = {1, 1, 1, 1};
	colorActive[] = {1, 0.50, 0, 1};
	soundEnter[] = {"", 0.10, 1};
	soundPush[] = {"", 0.10, 1};
	soundClick[] = {"", 0.10, 1};
	soundEscape[] = {"", 0.10, 1};
	text = "";
	default = false;
	colortext[] = {0, 0, 0, 1};
	font = "vbs_unicode_lite";
	sizeEx = .03;
};

//Standard picture.
class RscPicture
{
	idc = -1;
	type = CT_STATIC;
	style = ST_PICTURE;
	colorBackground[] = {0, 0, 0, 0};
	colorText[] = {1, 1, 1, 1};
	font = "TahomaB";
	sizeEx = 0;
	lineSpacing = 0;
	text = "";
};

//Picture that maintains its aspect ratio instead of stretching.
class RscPictureKeepAspect: RscPicture
{
	style = ST_PICTURE + ST_KEEP_ASPECT_RATIO;
};

//Standard button.
class RscButton
{
	idc = -1;
	type = CT_BUTTON;
	style = 0;
	x = 0;
	y = 0;
	w = 0.0975;
	h = 0.04;
	colorText[] = {0, 0, 0, 1};
	colorDisabled[] = {0.40, 0.40, 0.40, 1};
	colorBackground[] = {1, 1, 1, 1};
	colorBackgroundDisabled[] = {0.70, 0.70, 0.70, 0.80};
	colorBackgroundActive[] = {1, 0.50, 0, 1};
	colorFocused[] = {1, 0.50, 0, 1};
	colorShadow[] = {0.72, 0.36, 0, 0.80};
	colorBorder[] = {0.72, 0.36, 0, 0};
	soundEnter[] = {"", 0.10, 1};
	soundPush[] = {"", 0.10, 1};
	soundClick[] = {"", 0.10, 1};
	soundEscape[] = {"", 0.10, 1};
	offsetX = 0.0030;
	offsetY = 0.0030;
	offsetPressedX = 0.0020;
	offsetPressedY = 0.0020;
	borderSize = 0.0;
	font = "vbs_unicode_lite";
	sizeEx = .03;
	text = "";
};

//Invisible button
class RscInvisButton: RscActiveText
{
	style = ST_PICTURE;
	text = "#(argb,8,8,3)color(0,0,0,0)"; //invisible procedural texture to fill the entire control
};

//Standard edit text field.
class RscEdit
{
	idc = -1;
	type = CT_EDIT;
	style = 0;
	access = 0;
	h = 0.04;
	colorBackground[] = {0, 0, 0, 0.30};
	colorText[] = {0, 0, 0, 1};
	colorSelection[] = {1, 0.50, 0, 1};
	colorBorder[] = {1, 1, 1, 1};
	colorBorderActive[] = {1, 1, 1, 1};
	colorBorderFocused[] = {1, 1, 1, 1};
	autocomplete = "";
	size = 0.20;
	sizeEx = .0275;
	font = "vbs_unicode_lite";
	text = "";
};

//Standard listbox.
class RscListBox
{
	idc = -1;
	type = CT_LISTBOX;
	style = 16;
	access = 0;
	w = 0.40;
	h = 0.40;
	rowHeight = 0;
	colorText[] = {0, 0, 0, 1};
	colorScrollbar[] = {0, 0, 0, 0.30};
	colorSelect[] = {0, 0, 0, 1};
	colorSelect2[] = {0, 0, 0, 1};
	colorSelectBackground[] = {0, 0, 0, 0.20};
	colorSelectBackground2[] = {0.90, 0.45, 0, 0.60};
	colorBackground[] = {0, 0, 0, 1};
	soundSelect[] = {"", 0.10, 1};
	color[] = {1, 1, 1, 1};
	period = 0;
	font = "vbs_unicode_lite";
	sizeEx = .0275;
	canDrag = false;
};

//Standard combo box.
class RscCombo
{
	idc = -1;
	type = CT_COMBO;
	style = 0;
	access = 0;
	h = 0.0350;
	wholeHeight = 0.25;
	colorSelect[] = {0, 0, 0, 1};
	colorText[] = {0, 0, 0, 1};
	colorBackground[] = {1, 1, 1, 1};
	colorScrollbar[] = {0, 0, 0, 1};
	soundSelect[] = {"", 0.10, 1};
	soundExpand[] = {"", 0.10, 1};
	soundCollapse[] = {"", 0.10, 1};
	colorSelectBackground[] = {0.90, 0.45, 0, 0.60};
	font = "vbs_unicode_lite";
	sizeEx = .0275;
	arrowFull="\vbs2\ui\data\ui_arrow_down_active_ca.paa";
	arrowEmpty="\vbs2\ui\data\ui_arrow_down_ca.paa";
};

//Standard slider
class RscSlider
{
	idc = -1;
	type = CT_SLIDER;
	style = 1024;
	access = 0;
	w = 0.30;
	h = 0.0250;
	color[] = {0, 0, 0, 1};
	colorActive[] = {0, 0, 0, 1};
};

//Standard structured text (xml-like syntax; can hold images and text together).
class RscStructuredText
{
	idc = -1;
	type = CT_STRUCTURED_TEXT;
	style = 0;
	h = 0.05;
	colorText[] = {1, 1, 1, 1};
	class Attributes
	{
		font = "vbs_unicode_lite";
		color = "#ffffff";
		align = "center";
		shadow = true;
	};
	size = 0.020833;
	text = "";
};

//Standard HTML control.
class RscHTML
{
	idc = -1;
	type = CT_HTML;
	style = 0;
	colorBackground[] = {0, 0, 0, 0};
	colorText[] = {1, 1, 1, 1};
	colorBold[] = {0, 0, 0, 1};
	colorLink[] = {0.05, 0.20, 0.05, 1};
	colorLinkActive[] = {0, 0, 0.20, 1};
	colorPicture[] = {1, 1, 1, 1};
	colorPictureLink[] = {1, 1, 1, 1};
	colorPictureSelected[] = {1, 1, 1, 1};
	colorPictureBorder[] = {0, 0, 0, 0};
	tooltipColorText[] = {0, 0, 0, 1};
	tooltipColorBox[] = {0, 0, 0, 0.50};
	tooltipColorShade[] = {1, 1, 0.70, 1};
	align="left";
	filename = "";

	class H1
	{
		font = "Zeppelin32";
		fontBold = "Zeppelin33";
		sizeEx = 0.024740;
	};
	class H2
	{
		font = "Zeppelin32";
		fontBold = "Zeppelin33";
		sizeEx = 0.028646;
	};
	class H3
	{
		font = "Zeppelin32";
		fontBold = "Zeppelin33";
		sizeEx = 0.028646;
	};
	class H4
	{
		font = "Zeppelin33Italic";
		fontBold = "Zeppelin33";
		sizeEx = 0.020833;
	};
	class H5
	{
		font = "Zeppelin32";
		fontBold = "Zeppelin33";
		sizeEx = 0.020833;
	};
	class H6
	{
		font = "Zeppelin32";
		fontBold = "Zeppelin33";
		sizeEx = 0.020833;
	};
	class P
	{
		font = "Zeppelin32";
		fontBold = "Zeppelin33";
		sizeEx = 0.020833;
	};
	prevPage = "\ca\ui\data\arrow_left_ca.paa";
	nextPage = "\ca\ui\data\arrow_right_ca.paa";
};

//Standard controls group.
class RscControlsGroup
{
	idc = -1;
	type = CT_CONTROLS_GROUP;
	style = 0;
	x = 0;
	y = 0;
	w = 1;
	h = 1;
	class VScrollbar
	{
		color[] = {1, 1, 1, 1};
		width = 0.0210;
	};
	class HScrollbar
	{
		color[] = {1, 1, 1, 1};
		height = 0.0280;
	};
	class Controls
	{
		//place controls of this group in here
	};
};

//standard toolbox
//(similar to a radio button: a set of choices, where only one is
//always selected, and only one can be selected at a time)
class RscToolbox
{
	idc = -1;
	type = CT_TOOLBOX;
	style = ST_CENTER;
	colorText[] = {0, 0, 0, 1};
	color[] = {0, 0, 0, 1};
	colorTextSelect[] = {0, 0, 0, 1};
	colorSelect[] = {0, 0, 0, 1};
	colorTextDisable[] = {0.40, 0.40, 0.40, 1};
	colorDisable[] = {0.40, 0.40, 0.40, 1};
	font = "vbs_unicode_lite";
	SizeEx = .0275;
	strings[]= {""};
	rows=1;
	columns=3;
};

class RscXKey
{
	idc = -1;
	type = CT_XKEYDESC;
	style = 0;
	h = 0.06;
	size = "( 21 / 408 )";
	class Attributes
	{
		font = "FontX";
		color = "#C0C1BF";
		align = "left";
	};
	class AttributesImage
	{
		color = "#ffffff";
	};
};

//Standard progress bar (not useable: requires hardcoding in the engine)
class RscProgress
{
	idc = -1;
	type = CT_PROGRESS;
	style = 0;
	colorFrame[] = {0, 0, 0, 0};
	colorBar[] = {1, 0.50, 0, 1};
	x = 0.0;
	y = 0.91;
	w = 1;
	h = 0.08;
};

//Standard tree (not currently usable).
class RscTree
{
	access = 0;
	type = CT_TREE;
	style = 0;
	colorBackground[] = {0.35, 0.38, 0.36, 1};
	colorSelect[] = {1, 1, 1, 1};
	colorText[] = {1, 1, 1, 0.75};
	colorBorder[] = {1, 1, 1, 1};
	colorArrow[] = {1, 1, 1, 1};
	font = "Zeppelin32";
	sizeEx = 0.020833;
};

//Standard map.
class RscMapControl
{
	idc = 51;
	type = CT_MAP_MAIN;
	style = ST_PICTURE;
	colorBackground[] = {1, 1, 1, 1};
	colorText[] = {0, 0, 0, 1};
	sizeEx = 0.04;
	colorSea[] = {0.56, 0.80, 0.98, 0.50};
	colorForest[] = {0.60, 0.80, 0.20, 0.50};
	colorRocks[] = {0.60, 0.45, 0.27, 0.40};
	colorCountlines[] = {0.70, 0.55, 0.30, 0.60};
	colorMainCountlines[] = {0.65, 0.45, 0.27, 1};
	colorCountlinesWater[] = {0, 0.53, 1, 0.30};
	colorMainCountlinesWater[] = {0, 0.53, 1, 0.50};
	colorForestBorder[] = {0.40, 0.80, 0, 1};
	colorRocksBorder[] = {0.60, 0.45, 0.27, 0.40};
	colorPowerLines[] = {0, 0, 0, 1};
	colorBuildings[] = {0, 0, 0, 0.50};
	colorRailway[] = {0, 0, 0, 1};
	colorNames[] = {0, 0, 0, 1};
	colorInactive[] = {1, 1, 1, 0.50};
	colorLevels[] = {0.65, 0.45, 0.27, 1};

	stickX[] = {0.2, {"Gamma", 1, 1.5}};
	stickY[] = {0.2, {"Gamma", 1, 1.5}};

	fontLabel = "Zeppelin32";
	sizeExLabel = 0.028646;
	text = "#(argb,8,8,3)color(1,1,1,1,co)";
	font = "Zeppelin32";
	size = .0275;
	fontGrid = "NewsGothicB";
	sizeExGrid = 0.0180;
	fontUnits = "NewsGothicB";
	sizeExUnits = 0.04;
	fontNames = "NewsGothicB";
	sizeExNames = 0.04;
	fontInfo = "NewsGothicB";
	sizeExInfo = 0.04;
	fontLevel = "NewsGothicB";
	sizeExLevel = 0.0180;

	// Map drawing quality coefficients:
	//  units - the width of the screen == 800
	//  limits - size of the landscape square on screen when objects are drawn or single square content is drawn

	//@{ coefficients which determine rendering density / threshold
	ptsPerSquareSea = 0.1; // seas
	ptsPerSquareTxt = 8;   // textures
	ptsPerSquareCLn = 8;   // count-lines
	ptsPerSquareExp = 8;   // exposure
	ptsPerSquareCost = 8;  // cost
	//@}

	//@{ coefficients which determine when rendering of given type is done
	ptsPerSquareFor = 1;           // forests
	ptsPerSquareForEdge = "10.0f"; // forest edges
	ptsPerSquareRoad = "0.1f";     // roads
	ptsPerSquareObj = 5;           // other objects
	//@}

	showCountourInterval = "true"; // legend in upper right corner, with scaling information

	class Legend
	{
		colorBackground[] = {0.9060, 0.9010, 0.88, 0.80};
		color[] = {0, 0, 0, 1};
		x = 0.7290;
		y = 0.05;
		w = 0.2370;
		h = 0.1270;
		font = "Zeppelin32";
		sizeEx = 0.020833;
	};
	class ActiveMarker
	{
		color[] = {0.30, 0.10, 0.90, 1};
		size = 50;
	};
	class Command
	{
		color[] = {0, 0.90, 0, 1};
		icon = "#(argb,8,8,3)color(1,1,1,1,co)";
		size = 18;
		importance = 1; // not used
		coefMin = 1; // not used
		coefMax = 1; // not used
	};
	class Tree
	{
		color[] = {0.55, 0.64, 0.43, 1};
		icon = "\vbs2\ui\data\map\map_tree_ca.paa";
		size = 8;
		importance = "0.9 * 16 * 0.05"; // limit for map scale
		coefMin = 0.0010;
		coefMax = 8;
	};
	class SmallTree
	{
		color[] = {0.55, 0.64, 0.43, 1};
		icon = "\vbs2\ui\data\map\map_smalltree_ca.paa";
		size = 8;
		importance = "0.6 * 12 * 0.05";
		coefMin = 0.0010;
		coefMax = 4;
	};
	class Bush
	{
		color[] = {0.55, 0.64, 0.43, 1};
		icon = "\vbs2\ui\data\map\map_bush_ca.paa";
		size = 14;
		importance = "0.2 * 14 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Church
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_church_ca.paa";
		size = 16;
		importance = "2 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Chapel
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_chapel_ca.paa";
		size = 16;
		importance = "1 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Cross
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_cross_ca.paa";
		size = 16;
		importance = "0.7 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Rock
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_rock_ca.paa";
		size = 12;
		importance = "0.5 * 12 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Bunker
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_bunker_ca.paa";
		size = 14;
		importance = "1.5 * 14 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Fortress
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_bunker_ca.paa";
		size = 16;
		importance = "2 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Fountain
	{
		color[] = {0, 0.35, 0.70, 1};
		icon = "\vbs2\ui\data\map\map_fountain_ca.paa";
		size = 12;
		importance = "1 * 12 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class ViewTower
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_viewtower_ca.paa";
		size = 16;
		importance = "2.5 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Lighthouse
	{
		color[] = {0.78, 0, 0.05, 1};
		icon = "\vbs2\ui\data\map\map_lighthouse_ca.paa";
		size = 20;
		importance = "3 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Quay
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_quay_ca.paa";
		size = 16;
		importance = "2 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Fuelstation
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_fuelstation_ca.paa";
		size = 16;
		importance = "2 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Hospital
	{
		color[] = {0.78, 0, 0.05, 1};
		icon = "\vbs2\ui\data\map\map_hospital_ca.paa";
		size = 16;
		importance = "2 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class BusStop
	{
		color[] = {0, 0, 1, 1};
		icon = "\vbs2\ui\data\map\map_busstop_ca.paa";
		size = 10;
		importance = "1 * 10 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Transmitter
	{
		color[] = {0, 0, 1, 1};
		icon = "\vbs2\ui\data\map\map_transmitter_ca.paa";
		size = 20;
		importance = "2 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Stack
	{
		color[] = {0, 0, 1, 1};
		icon = "\vbs2\ui\data\map\map_stack_ca.paa";
		size = 20;
		importance = "2 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Ruin
	{
		color[] = {0.78, 0, 0.05, 1};
		icon = "\vbs2\ui\data\map\map_ruin_ca.paa";
		size = 16;
		importance = "1.2 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Tourism
	{
		color[] = {0.78, 0, 0.05, 1};
		icon = "\vbs2\ui\data\map\map_tourism_ca.paa";
		size = 16;
		importance = "1 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 8;
	};
	class Watertower
	{
		color[] = {0, 0.35, 0.70, 1};
		icon = "\vbs2\ui\data\map\map_watertower_ca.paa";
		size = 32;
		importance = "1.2 * 16 * 0.05";
		coefMin = 0.25;
		coefMax = 4;
	};
	class Waypoint
	{
		color[] = {0, 0, 0, 1};
		size = 24;
		importance = 1;
		coefMin = 1;
		coefMax = 1;
		icon = "\vbs2\ui\data\map\map_waypoint_ca.paa";
	};
	class WaypointCompleted
	{
		color[] = {0, 0, 0, 1};
		size = 24;
		importance = 1;
		coefMin = 1;
		coefMax = 1;
		icon = "\vbs2\ui\data\map\map_waypoint_completed_ca.paa";
	};
};

//Standard 3d object (p3d model)
class RscObject
{
	idc = -1;
	type = CT_OBJECT;
	scale = 1.0;
	direction[] = {0, 0, 1};
	up[] = {0, 1, 0};
};

/*
//example 3d object
class RscCompass: RscObject
{
	idc = -1;
	type = CT_OBJECT_ZOOM;
	selectionArrow = "arrow";
	position[] = {0., -0.10, 0.20};
	direction[] = {0, 0.30, 1};
	up[] = {0, 1, 0};
	positionBack[] = {0, -0.02, 0.0750};
	inBack = true;
	enableZoom = false;
	zoomDuration = 0.50;
	model = "\vbs2\ui\data\compass\compass.p3d";
	scale = 0.50;

	//animations are in the same format as model.cfg animations
	class Animations
	{
		class Pointer
		{
			type = "rotation";
			source = "compassPointer";
			selection = "kompas";
			axis = "osa kompasu";
			memory = 1;
			animPeriod = 0;
			minValue = "rad -180";
			maxValue = "rad 180";
			angle0 = "rad -180";
			angle1 = "rad 180";
		};
		class Arrow
		{
			type = "rotation";
			source = "compassArrow";
			selection = "arrow";
			axis = "osa kompasu";
			memory = 1;
			animPeriod = 0;
			minValue = "rad -180";
			maxValue = "rad 180";
			angle0 = "rad -180";
			angle1 = "rad 180";
		};
		class Cover
		{
			type = "rotation";
			source = "compassCover";
			selection = "vicko";
			axis = "osa vicka";
			memory = 1;
			animPeriod = 0;
			angle0 = 0;
			angle1 = "rad -81";
		};
	};
};
*/