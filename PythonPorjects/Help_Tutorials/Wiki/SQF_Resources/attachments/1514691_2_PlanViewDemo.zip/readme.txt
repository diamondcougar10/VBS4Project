In order to use the demo mission for planViews, execute the following steps:

1) Place the enclosed PBO into your \mycontent\addons folder.
2) Place the Dialog_Plan.Intro folder into you MPmission folder.
3) Start VBS, and open the demo mission  in the editor.

The sources for the example addon can be downloaded from
https://resources.bisimulations.com/download/Demo_PlanView_AddonSources.zip
