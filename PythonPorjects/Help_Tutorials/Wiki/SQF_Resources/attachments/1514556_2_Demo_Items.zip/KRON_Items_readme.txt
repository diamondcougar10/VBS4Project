This addon contains two example items ("ItemBall" & "ItemCube"),
which can be added to a unit via addWeapon (e.g. player addWeapon "ItemBall").

They will show up in the inventory, but cannot be used directly in any way.
See the article on "items" in the wiki for more information:
http://resources.bisimulations.com/wiki/items


The example uses models and previews from existing objects,
and consists only of the following config.cpp:

class CfgPatches
{
	class KRON_Items
	{
		units[]={};
		weapons[]={};
		requiredVersion=1.0;
	};
};



class CfgWeapons 
{
	class Default;
	
	// Currently (2.05) this base class doesn't exist in VBS2 by default,
	// so it has to be created manually.
	// It *might* become part of the default VBS2 configuration at some later
	// point though, in which case the base class would be called "ItemCore",
	// so this should be kept in mind for future reference.
	class MyItems: Default
	{
		type = 131072;	// type: Item
		vbs_entity=1;		// to suppress the "(Game)" prefix in some listings
	};
 
	class ItemBall: MyItems
	{
		scope = 2;
		displayName = "Ball";
		// we're just using some existing models and previews for the example
		model = \vbs2\structures\visualizations\sphere_10cm.p3d;
		picture = \vbs2\structures\visualizations\data\ico\preview_sphere_ca;
		descriptionShort = "Ball Item"; // currently not displayed in inventory
	};
	
	class ItemCube: ItemBall
	{
		displayName = "Cube";
		model = \vbs2\structures\visualizations\cube_100cm.p3d;
		picture = \vbs2\structures\visualizations\data\ico\preview_cube_ca;
		descriptionShort = "Cube Item";
	};
};