Installation:
  Place these folders into your \My Documents\VBS2\MPmissions folder.
  
Usage:
  1) Open the Mission Editor.
  2) Select "Island: Rahmadi".
  3) Select "File | Load" - chose desired mission.
  4) Press "H" to preview (or select "File | Preview").
     Read the briefing page for detailed explanations.