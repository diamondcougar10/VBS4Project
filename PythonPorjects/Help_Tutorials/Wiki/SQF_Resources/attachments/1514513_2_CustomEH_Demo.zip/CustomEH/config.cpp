#define __CurrentDir__ \vbs2\structures\visualizations
#include "\vbs2\basic_defines.hpp"

class CfgPatches
{
  class VBS2_CustomEH_Demo
  {
    units[] = {};
    weapons[] = {};
    requiredVersion = 0.10;
    requiredAddons[] = {};
  };
};

class CfgSystemEventHandlers {
  class editorLoad {
    // add an arrow above player when Real-time editor is opened
    nul = "if (_this select 0=='RTE') then {_arrow='vbs2_editor_waypoint_blue' createVehicle (getPos player); _arrow attachTo[player,[0,0,3]]}";
  };

  class editorUnload {
    // remove arrow when editor is closed
    nul = "{if (typeOf _x=='vbs2_editor_waypoint_blue') then {deleteVehicle _x}}forEach (attachedObjects player)"; 
  };
};
