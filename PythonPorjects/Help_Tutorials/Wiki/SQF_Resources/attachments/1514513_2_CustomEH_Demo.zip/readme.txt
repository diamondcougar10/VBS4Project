This content of this zip file contains demo elements to demonstrate VBS2 Custom Event Handlers:
http://resources.bisimulations.com/wiki/index.php?title=VBS2:_Custom_Event_Handlers

* Folder "CustomEH"
  Contains the sources for an addon-based custom EH.
  
* File "CustomEH.pbo"
  Packed version of the above addon.
  If this addon is placed into your mycontent\addons folder, 
  the custom EH will fire every time the real-time editor is opened 
  (to create a waypoint marker above the player's head).
  
* Image "CustomEHDemo.jpg"
  Screenshot of what the effect of the above addon looks like.
  
* Folder "CustomEH.Intro"
  If this mission is placed into your [VBS2 profile folder]\MPmissions folder,
  it can be started from the editor, to demonstrate custom event handlers
  that are initiated via a function-call (as opposed to config-based ones).
  It also demonstrates the use of a custom EH that is wholly user-defined
  (fires whenever a vehicle in the mission is started).