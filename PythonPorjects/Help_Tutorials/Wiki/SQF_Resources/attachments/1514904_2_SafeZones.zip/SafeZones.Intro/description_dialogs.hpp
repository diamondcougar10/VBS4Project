#define true 1
#define false 0

#define ReadAndWrite 0 //! any modifications enabled
#define ReadAndCreate 1 //! only adding new class members is allowed
#define ReadOnly 2 //! no modifications enabled
#define ReadOnlyVerified 3 //! no modifications enabled, CRC test applied


//---------------------------------
// Control types
//---------------------------------

//2D controls
#define CT_STATIC           0
#define CT_BUTTON           1
#define CT_EDIT             2
#define CT_SLIDER           3
#define CT_COMBO            4
#define CT_LISTBOX          5
#define CT_TOOLBOX          6
#define CT_CHECKBOXES       7
#define CT_PROGRESS         8
#define CT_HTML             9
#define CT_STATIC_SKEW      10
#define CT_ACTIVETEXT       11
#define CT_TREE             12
#define CT_STRUCTURED_TEXT  13
#define CT_CONTEXT_MENU     14
#define CT_CONTROLS_GROUP   15
#define CT_XKEYDESC         40
#define CT_XBUTTON          41
#define CT_XLISTBOX         42
#define CT_XSLIDER          43
#define CT_XCOMBO           44
#define CT_ANIMATED_TEXTURE 45
#define CT_LINEBREAK        98
#define CT_USER             99
#define CT_MAP              100
#define CT_MAP_MAIN         101

//3D controls
#define CT_OBJECT           80
#define CT_OBJECT_ZOOM      81
#define CT_OBJECT_CONTAINER 82
#define CT_OBJECT_CONT_ANIM 83

//todo: verify these
#define CT_3DSTATIC     20
#define CT_3DACTIVETEXT 21
#define CT_3DLISTBOX    22
#define CT_3DHTML       23
#define CT_3DSLIDER     24
#define CT_3DEDIT       25


//---------------------------------
// Control styles
//---------------------------------

//many of these can be combined; eg: style = ST_RIGHT + ST_SHADOW;

//static styles
#define ST_POS            0x0F
#define ST_HPOS           0x03
#define ST_VPOS           0x0C
#define ST_LEFT           0x00 //left aligned text
#define ST_RIGHT          0x01 //right aligned text
#define ST_CENTER         0x02 //center aligned text
#define ST_DOWN           0x04
#define ST_UP             0x08
#define ST_VCENTER        0x0c

#define ST_TYPE           0xF0
#define ST_SINGLE         0    //single line textbox
#define ST_MULTI          16   //multi-line textbox (text will wrap, and newline character can be used). There is no scrollbar, but mouse wheel/arrows can scroll it. Control will be outlined with a line (color = text color).
#define ST_TITLE_BAR      32
#define ST_PICTURE        48   //turns a static control into a picture control. 'Text' will be used as picture path. Picture will be stretched to fit the control.
#define ST_FRAME          64   //control becomes a frame. Background is clear and text is placed along the top edge of the control. Control is outlined with text color (as in ST_MULTI).
#define ST_BACKGROUND     80
#define ST_GROUP_BOX      96
#define ST_GROUP_BOX2     112
#define ST_HUD_BACKGROUND 128  //control is rounded and outlined (just like a hint box)
#define ST_TILE_PICTURE   144
#define ST_WITH_RECT      160
#define ST_LINE           176  //a line is drawn between the top left and bottom right of the control (color = text color). Background is clear. Control can still have text, however.

#define ST_SHADOW         0x100 //text or image is given a shadow
#define ST_NO_RECT        0x200 //when combined with ST_MULTI, it eliminates the outline around the control. Might combine with other styles for similar effect.
#define ST_KEEP_ASPECT_RATIO  0x800 //used for pictures, it makes the displayed picture keep its aspect ratio.

#define ST_TITLE          ST_TITLE_BAR + ST_CENTER

// Slider styles
#define SL_DIR            0x400
#define SL_VERT           0
#define SL_HORZ           0x400

#define SL_TEXTURES       0x10

// Listbox styles
#define LB_TEXTURES       0x10   //removes all extra lines from listbox, leaving only a gradiant scrollbar. Useful when LB has a painted background behind it.
#define LB_MULTI          0x20   //allows multiple elements of the LB to be selected (by holding shift / ctrl)

// Tree styles
#define TR_SHOWROOT       1
#define TR_AUTOCOLLAPSE   2

// MessageBox styles
#define MB_BUTTON_OK      1
#define MB_BUTTON_CANCEL  2
#define MB_KEY_X          4
#define MB_KEY_Y          8
#define MB_KEY_START      16


//Fonts
#define FONTVBS2LITE "vbs_unicode_lite"
#define FontMAIN "TahomaB"
#define FontDEBUG "LucidaConsoleB"

//Main sizes
#define Size_Main_Very_Small 0.018
#define Size_Main_Small 0.027
#define Size_Main_Normal 0.03
#define Size_Main_ToolTip 0.03

//Control sizes
#define Size_Text_Default Size_Main_Normal
#define Size_Text_Very_Small Size_Main_Very_Small
#define Size_Text_Small Size_Main_Small

// Text sizes
#define TextSize_xsmall       1.25*0.014
#define TextSize_IGUI_normal  1.25*0.023
#define TextSize_small        1.25*0.022
#define TextSize_editor       0.020
#define TextSize_normal       1.25*0.024
#define TextSize_medium       1.25*0.027
#define TextSize_large        1.25*0.057


//Base colors
#define Color_Black {0, 0, 0, 1}
#define Color_White {1, 1, 1, 1}
#define Color_WhiteDark {0.85, 0.85, 0.85, 1}
#define Color_Orange {1, 0.5, 0, 1}
#define Color_Gray {0.3, 0.3, 0.3, 1}
#define Color_GrayLight {0.6, 0.6, 0.6, 1}
#define Color_GrayDark {0.2, 0.2, 0.2, 1}
#define VBS2_UI_title_background_semi_transparent {0.9, 0.45, 0, 0.6}

//Colors w/out alpha
#define Black 0, 0, 0
#define Green 0.0, 0.6, 0.0
#define Red 0.7, 0.1, 0.0
#define Yellow 0.8, 0.6, 0.0
#define White 0.8, 0.8, 0.8
#define ShineGreen 0.07, 0.7, 0.2
#define ShineRed 1, 0.2, 0.2
#define ShineYellow 1, 1, 0
#define ShineWhite 1, 1, 1
#define Blue 0.1, 0.1, 0.9
#define Gray1 0.00, 0.00, 0.00
#define Gray2 0.20, 0.20, 0.20
#define Gray3 0.50, 0.50, 0.50
#define Gray4 0.60, 0.60, 0.60
#define Gray5 0.80, 0.80, 0.80

//Main colors
#define Color_Main_Active1 Color_GrayLight
#define Color_Main_Select1 Color_WhiteDark
#define Color_Main_Foreground1 Color_White
#define Color_Main_Background1 Color_Gray
#define Color_Main_Background2 Color_Gray

//Control colors
#define Color_Text_Default Color_Main_Foreground1
#define Color_Text_Orange Color_Main_Foreground1
#define Color_Background Color_Main_Background1
#define Color_Text_White Color_White

//Procedural colors
#define ProcTextWhite "#(argb,8,8,3)color(1,1,1,1)"
#define ProcTextBlack "#(argb,8,8,3)color(0,0,0,1)"
#define ProcTextGray "#(argb,8,8,3)color(0.3,0.3,0.3,1)"
#define ProcTextRed "#(argb,8,8,3)color(1,0,0,1)"
#define ProcTextGreen "#(argb,8,8,3)color(0,1,0,1)"
#define ProcTextBlue "#(argb,8,8,3)color(0,0,1,1)"
#define ProcTextOrange "#(argb,8,8,3)color(1,0.5,0,1)"

//More shades of gray procedural colors commonly used
#define ProcTextGray1 "#(argb,8,8,3)color(0.1,0.1,0.1,1)"
#define ProcTextGray2 "#(argb,8,8,3)color(0.2,0.2,0.2,1)"
#define ProcTextGray3 "#(argb,8,8,3)color(0.3,0.3,0.3,1)"
#define ProcTextGray4 "#(argb,8,8,3)color(0.4,0.4,0.4,1)"
#define ProcTextGray5 "#(argb,8,8,3)color(0.5,0.5,0.5,1)"
#define ProcTextGray6 "#(argb,8,8,3)color(0.6,0.6,0.6,1)"
#define ProcTextGray7 "#(argb,8,8,3)color(0.7,0.7,0.7,1)"
#define ProcTextGray8 "#(argb,8,8,3)color(0.8,0.8,0.8,1)"
#define ProcTextGray9 "#(argb,8,8,3)color(0.9,0.9,0.9,1)"


//VBS2NG compat.
#define SCROLLBAR \
	class ScrollBar \
	{ \
		color[] = {1,1,1,0.6}; \
		colorActive[] = {1,1,1,1}; \
		colorDisabled[] = {1,1,1,0.3}; \
  		thumb = ProcTextWhite;\
  		arrowEmpty = ProcTextWhite;\
  		arrowFull = ProcTextWhite;\
  		border = ProcTextWhite;\
      shadow = 0;\
	};	

//Default text/font attributes for structured text controls.
class DefaultTextAttributes
{
	font = FontMAIN;
	color = "#ffffff";
	size = 1;
	align = "left";
	valign = "middle";
	shadow = "true";
	shadowOffset = 0.1;
	shadowColor = "#000000";
	underline = "false";
	shadowAlpha = 1;
};

//Default sounds for controls.
class DefaultSounds
{
	soundOK[] = {"", 0.1, 1};
	soundCancel[] = {"", 0.1, 1};
	soundChangeFocus[] = {"", 0.1, 1};
	soundFail[] = {"", 0.1, 1};
};

//Standard static text.
class RscText
{
	idc = -1;
	access = ReadAndWrite;
	type = CT_STATIC;
	style = ST_LEFT;
	w = 0.1;
	h = 0.05;
	font = FontMAIN;
	sizeEx = Size_Text_Small;
	colorBackground[] = {0, 0, 0, 0};
	colorText[] = Color_Text_Default;
	text = "";
	autoScrollSpeed = -1;
	autoScrollDelay = 5;
	autoScrollRewind = false;
	arrowEmpty = ProcTextWhite;
	arrowFull = ProcTextWhite;
	shadow = 0;
	SCROLLBAR
	colorSelect[] = Color_Black;
	rowHeight = 0;
	maxHistoryDelay = 1.0; 
	soundSelect[] = {"", 0.1, 1};
};

//Small static text.
class RscTextSmall: RscText
{
	h = 0.03;
	sizeEx = Size_Text_Small;
};

//Standard static text title.
class RscTitle: RscText
{
	style = ST_CENTER;
	x = 0.15;
	y = 0.06;
	w = 0.7;
  shadow = 0;
};

//Multi-line text.
class RscTextMulti: RscText
{
	style = ST_LEFT + ST_MULTI;
	linespacing = 1;
};

//Standard progress bar.
class RscProgress
{
	access = ReadAndWrite;
	type = CT_PROGRESS;
	style = 0;
	colorFrame[] = Color_Text_Default;
	colorBar[] = Color_Text_Default;
	texture = ProcTextWhite; 
	w = 1.2;
	h = 0.03;
  shadow = 0;
};
class RscProgressNotFreeze
{
  idc = -1;
  type = CT_ANIMATED_TEXTURE;
  style = 0;
  shadow = 0;
  x = 0;
  y = 0;
  w = 0.5;
  h = 0.1;
  texture = ProcTextTransparent;
};

class RscPicture
{
	access = ReadAndWrite;
	type = CT_STATIC;
	idc = -1;
	style = ST_PICTURE;
	colorBackground[] = {0, 0, 0, 0};
	colorText[] = {1, 1, 1, 1};
	font = FontMAIN;
	sizeEx = 0;
	lineSpacing = 0;
	text = "";
  shadow = 0;
};

//Picture that maintains its aspect ratio instead of stretching.
class RscPictureKeepAspect: RscPicture
{
	style = ST_PICTURE + ST_KEEP_ASPECT_RATIO;
};

//Standard HTML control.
class RscHTML
{
	access = ReadAndWrite;
	type = CT_HTML;
	idc = -1;
	style = 0;
	filename = "";
	colorBackground[] = {0, 0, 0, 0};
	colorText[] = Color_Text_Default;
	colorBold[] = {0, 0, 0.2, 1};
	colorLink[] = Color_Orange;
	colorLinkActive[] = Color_Orange;
	colorPicture[] = {1, 1, 1, 1};
  colorPictureLink[] = {1, 1, 1, 1};
	colorPictureSelected[] = {1, 1, 1, 1};
	colorPictureBorder[] = {0, 0, 0, 0};
	tooltipColorText[] = {0, 0, 0, 1};
	tooltipColorBox[] = {0, 0, 0, 0.5};
	tooltipColorShade[] = {1, 1, 0.7, 1};
  shadow = 0;

  prevPage = ProcTextWhite;
  nextPage = ProcTextWhite;

	class H1
	{
		font = FontMAIN;
		fontBold = FontMAIN;
		sizeEx = Size_Text_Default;
	};

	class H2
	{
		font = FontMAIN;
		fontBold = FontMAIN;
		sizeEx = Size_Text_Default;
	};

	class H3
	{
		font = FontMAIN;
		fontBold = FontMAIN;
		sizeEx = Size_Text_Default;
	};

	class H4
	{
		font = FontMAIN;
		fontBold = FontMAIN;
		sizeEx = Size_Text_Default;
	};

	class H5
	{
		font = FontMAIN;
		fontBold = FontMAIN;
		sizeEx = Size_Text_Default;
	};

	class H6
	{
		font = FontMAIN;
		fontBold = FontMAIN;
		sizeEx = Size_Text_Default;
	};

	class P
	{
		font = FontMAIN;
		fontBold = FontMAIN;
		sizeEx = Size_Text_Default;
	};
};

//Standard button.
class RscButton
{
	idc = -1;
  // common control items
	access = ReadAndWrite;
	type = CT_BUTTON;
	style = ST_LEFT;
  x = 0;
  y = 0;
	w = 0.3;
	h = 0.1;

  // text properties
  text = "";
	font = FontMAIN;
	sizeEx = Size_Text_Default;
	colorText[] = Color_Black;
  colorDisabled[] = Color_Gray;

  // background properties
  colorBackground[] = Color_GrayLight;
  colorBackgroundDisabled[] = Color_GrayLight;
  colorBackgroundActive[] = Color_Orange;
  offsetX = 0.004; // distance of background from shadow
  offsetY = 0.004;
  offsetPressedX = 0.002; // distance of background from shadow when button is pressed
  offsetPressedY = 0.002;
  colorFocused[] = Color_Black; // color of the rectangle around background when focused

  // shadow properties
  colorShadow[] = Color_Black;
  shadow = 0;

  // border properties
  colorBorder[] = Color_Black;
  borderSize = 0.008; // when negative, the border is on the right side of background

  // sounds
  soundEnter[] = {"", 0.1, 1};
  soundPush[] = {"", 0.1, 1};
	soundClick[] = {"", 0.1, 1};
	soundEscape[] = {"", 0.1, 1};
};

class RscShortcutButton
{
  type = CT_SHORTCUTBUTTON;
  style = 0;	
  x = 0.1;
  y = 0.1;
  w = 0.3;
  h = 0.05;
  shadow = 0;

  class HitZone
  {
    left = 0.0;
    top = 0.0;
    right = 1.0;
    bottom = 1.0;
  };   
  class ShortcutPos
  {
    left = 0.005;
    top = 0.005;
    w = 0.0225; // aspect 4 : 3
    h = 0.03;
  };   
  class TextPos
  {
    left = 0.02;
    top = 0.005;
    right = 0.005;
    bottom = 0.005;
  };   
  // background animated textures    
  animTextureNormal = ProcTextWhite;
  animTextureDisabled = ProcTextGray;
  animTextureOver = "#(argb,8,8,3)color(0.8,0.3,0,1)";
  animTextureFocused = "#(argb,8,8,3)color(1,0.5,0,1)";
  animTexturePressed = ProcTextRed;
  animTextureDefault = ProcTextGreen;

  period = 0.1;
  periodFocus = 0.4; // color animation period
  periodOver = 0.4; // color animation period

  shortcuts[] = {};
  textureNoShortcut = ProcTextTransparent;  // texture to show when no shortcut is accessible

  color[] = {0,0,0,0.6}; // text and icon color
  color2[] = {0,0,0,1}; // secondary text and icon color
  colorDisabled[] = {0,0,0,0.3}; // text and icon color

  colorBackground[] = {1,1,1,1}; // text and icon color
  colorBackground2[] = {1,1,1,0.5}; // secondary text and icon color

  text = "";
  size = 0.04; // text height
  class Attributes
  {
    font = FontMAIN;
    color = "#000000";
    align = "left";
    shadow = false;
  };
};

class RscButtonSmall: RscButton
{
	w = 0.12;
};

//Standard edit text field.
class RscEdit
{
	access = ReadAndWrite;
	type = CT_EDIT;
	style = ST_LEFT;
	h = 0.04;
	colorBackground[] = {0, 0, 0, 0};
	colorText[] = Color_Text_Default;
	colorSelection[] = {1, 1, 1, 0.25};
	font = FontMAIN;
	sizeEx = Size_Text_Default;
	autocomplete = "";
	text = "";
	size = 0.2;
  shadow = 0;
};

//Standard combo box.
class RscCombo
{
	access = ReadAndWrite;
	type = CT_COMBO;
	style = 0;
	h = 0.05;
	wholeHeight = 0.25;
	colorSelect[] = Color_GrayLight;
	colorText[] = Color_Text_Default;
	colorBackground[] = Color_GrayDark;
  colorScrollbar[] = Color_Text_Default;
	font = FontMAIN;
	sizeEx = Size_Text_Default;
  soundSelect[] = {"", 0.1, 1};
  soundExpand[] = {"", 0.1, 1};
  soundCollapse[] = {"", 0.1, 1};
  maxHistoryDelay = 1.0; 
  shadow = 0;
  SCROLLBAR 
};

//Standard listbox.
class RscListBox
{
	access = ReadAndWrite;
	type = CT_LISTBOX;
	style = 0;
	w = 0.4;
	h = 0.4;
	font = FontMAIN;
	sizeEx = Size_Text_Default;
	rowHeight = 0;
	colorText[] = Color_Text_Default;
  colorScrollbar[] = Color_Text_Default;
	colorSelect[] = Color_Black;
	colorSelect2[] = Color_Orange;
 	colorSelectBackground[] = Color_GrayLight;
	colorSelectBackground2[] = Color_GrayDark;
  colorBackground[] = Color_Black;
  highlightColorBackground[] = {0.1, 0.4, 0.4, 1};
  disableFiltering = false;
  maxHistoryDelay = 1.0; 
  soundSelect[] = {"", 0.1, 1};
	period = 1;
  autoScrollSpeed = -1;
  autoScrollDelay = 5;
  autoScrollRewind = false;
  arrowEmpty = ProcTextWhite;
  arrowFull = ProcTextWhite;
  shadow = 0;
	SCROLLBAR
};

class RscListNBox {
	access = ReadAndWrite;
	type = 102;
	style = 0;
	w = 0.4;
	h = 0.4;
	font = "TahomaB";
	sizeEx = 0.04;
	rowHeight = 0;
	colorText[] = {1, 1, 1, 1};
	colorScrollbar[] = {1, 1, 1, 1};
	colorSelect[] = {0, 0, 0, 1};
	colorSelect2[] = {1, 0.5, 0, 1};
	colorSelectBackground[] = {0.6, 0.6, 0.6, 1};
	colorSelectBackground2[] = {0.2, 0.2, 0.2, 1};
	colorBackground[] = {0, 0, 0, 1};
	maxHistoryDelay = 1.0;
	soundSelect[] = {"", 0.1, 1};
	period = 1;
	autoScrollSpeed = -1;
	autoScrollDelay = 5;
	autoScrollRewind = 0;
	arrowEmpty = "#(argb,8,8,3)color(1,1,1,1)";
	arrowFull = "#(argb,8,8,3)color(1,1,1,1)";
	drawSideArrows = 0;
	columns[] = {0.3, 0.6, 0.7};
	idcLeft = -1;
	idcRight = -1;
  shadow = 0;
	
	class ScrollBar {
		color[] = {1, 1, 1, 0.6};
		colorActive[] = {1, 1, 1, 1};
		colorDisabled[] = {1, 1, 1, 0.3};
		thumb = "#(argb,8,8,3)color(1,1,1,1)";
		arrowEmpty = "#(argb,8,8,3)color(1,1,1,1)";
		arrowFull = "#(argb,8,8,3)color(1,1,1,1)";
		border = "#(argb,8,8,3)color(1,1,1,1)";
	};
};

class RscXListBox {
	idc = -1;
	style = 0;
	type = 42;
	x = 0.1;
	y = 0.1;
	w = 0.3;
	h = 0.05;
	color[] = {1, 1, 1, 0.6};
	colorActive[] = {1, 1, 1, 1};
	colorDisabled[] = {1, 1, 1, 0.3};
	arrowEmpty = "#(argb,8,8,3)color(1,1,1,1)";
	arrowFull = "#(argb,8,8,3)color(1,0.5,0,1)";
	border = "#(argb,8,8,3)color(0,0,0,1)";
	colorSelect[] = {1, 1, 1, 1};
	colorText[] = {1, 1, 1, 0.8};
	font = "TahomaB";
	sizeEx = 0.04;
	soundSelect[] = {"", 0.1, 1};
  shadow = 0;
};

class RscTree
{
	access = ReadAndWrite;
	type = CT_TREE;
	style = 0;
	colorBackground[] = {0.35, 0.38, 0.36, 1};
	colorSelect[] = {1, 1, 1, 1};
	colorText[] = {1, 1, 1, 0.75};
	colorBorder[] = {1, 1, 1, 1};
	colorArrow[] = {1, 1, 1, 1};
	font = FontMAIN;
	sizeEx = Size_Text_Default;
  maxHistoryDelay = 1.0; 
  shadow = 0;
};

//Standard slider
class RscSlider
{
	access = ReadAndWrite;
	type = CT_SLIDER;
	style = SL_HORZ;
	h = 0.028;
	w = 0.3;
	color[] = Color_Text_Default;
	colorActive[] = {1, 1, 1, 1};
	colorText[] = Color_Text_Default;
	colorBackground[] = {0.35, 0.38, 0.36, 0.8};
	font = FontMAIN;
	sizeEx = Size_Text_Default;
	text = "";
  shadow = 0;
};

//Remove
class RscSliderH: RscSlider {};

class RscXSliderH {
	type = 43;
	style = 0x400  + 0x10;
	h = "scalar";
	color[] = {1, 1, 1, 0.6};
	colorActive[] = {1, 1, 1, 1};
	colorDisable[] = {1, 1, 1, 0.4};
	arrowEmpty = "#(argb,8,8,3)color(1,1,1,1)";
	arrowFull = "#(argb,8,8,3)color(1,1,1,1)";
	border = "#(argb,8,8,3)color(1,1,1,1)";
	thumb = "#(argb,8,8,3)color(1,1,1,1)";
  shadow = 0;
};

//Standard active text.
class RscActiveText
{
	idc = -1;
	access = ReadAndWrite;
	type = CT_ACTIVETEXT;
	style = ST_CENTER;
	h = 0.05;
	w = 0.15;
	font = FontMAIN;
	sizeEx = Size_Text_Default;
  color[] = Color_Text_Default;
	colorText[] = Color_Text_Default;
	colorActive[] = {1, 0.5, 0, 1};
	colorBackground[] = {0.35, 0.38, 0.36, 0};
	soundEnter[] = {"", 0.1, 1};
	soundPush[] = {"", 0.1, 1};
	soundClick[] = {"", 0.1, 1};
	soundEscape[] = {"", 0.1, 1};
	text = "";
	default = 0;
  shadow = 0;
};


//Invisible button
class RscInvisButton: RscActiveText
{
	style = ST_PICTURE;
	text = "#(argb,8,8,3)color(0,0,0,0)"; //invisible procedural texture to fill the entire control
};

//Standard structured text.
class RscStructuredText
{
	access = ReadAndWrite;
	type = CT_STRUCTURED_TEXT;
	idc = -1;
	style = 0;
	h = 0.05;
	text = "";
	size = Size_Text_Default;
	colorText[] = Color_Text_Default;
  shadow = 0;

	class Attributes
	{
		font = FontMAIN;
		color = "#ffffff";
		align = "center";
		shadow = true;
    shadowAlpha = 1;
	};
};

//Standard controls group.
class RscControlsGroup
{
  type = CT_CONTROLS_GROUP;
  idc = -1;
  style = 0;
  x = 0; y = 0;
  w = 1; h = 1;
  shadow = 0;
	colorBackground[] = {0.35, 0.38, 0.36, 0};
	colorText[] = Color_Text_Default;
	font = FontMAIN;
	sizeEx = Size_Text_Default;
	text = "";

  class VScrollbar
  {
    color[] = Color_Text_Default;
    width = 0.021;
    autoScrollSpeed = -1; 
    autoScrollDelay = 5; 
    autoScrollRewind = false; 
    shadow = 0;
  };

  class HScrollbar
  {
    color[] = Color_Text_Default;
    height = 0.028;
    shadow = 0;
  };
  
	class ScrollBar {
		color[] = {1, 1, 1, 0.6};
		colorActive[] = {1, 1, 1, 1};
		colorDisabled[] = {1, 1, 1, 0.3};
		thumb = "#(argb,8,8,3)color(1,1,1,1)";
		arrowEmpty = "#(argb,8,8,3)color(1,1,1,1)";
		arrowFull = "#(argb,8,8,3)color(1,1,1,1)";
		border = "#(argb,8,8,3)color(1,1,1,1)";
	};

  class Controls {};
};

class RscBackgroundStripeTop: RscText
{
	access = ReadAndWrite;
	x = -10.0;
	y = -10.0;
	w = 21;
	h = 10.125;
	text = ;
	colorBackground[] = {0.1, 0.1, 0.1, 1};
};

class RscBackgroundStripeBottom: RscText
{
	access = ReadAndWrite;
	x = -10.0;
	y = 0.875;
	w = 21;
	h = 10.125;
	text = ;
	colorBackground[] = {0.1, 0.1, 0.1, 1};
};

class RscDisplayBackgroundStripes
{
	access = ReadAndWrite;
	class Background1: RscBackgroundStripeTop {};
	class Background2: RscBackgroundStripeBottom {};
};

class RscCinemaBorder: RscDisplayBackgroundStripes
{
	idd = -1;
	movingEnable = false;
	enableSimulation = 1;

	class controlsBackground
	{
		class Background1: RscBackgroundStripeTop
		{
		  	colorBackground[] = {0, 0, 0, 1};
		};

		class Background2: RscBackgroundStripeBottom
		{
		  	colorBackground[] = {0, 0, 0, 1};
		};
	};
};

//Standard toolbox.
class RscToolbox
{
	access = ReadAndWrite;
	type = CT_TOOLBOX;
	style = ST_CENTER;
	colorText[] = Color_Text_Default;
	color[] = Color_Text_Default;
	colorTextSelect[] = Color_Text_Default;
	colorSelect[] = Color_Text_Default;
	colorTextDisable[] = Color_Text_Default;
	colorDisable[] = Color_Text_Default;
	coloSelectedBg[] = {0, 0, 0, 255};
	font = FontMAIN;
	sizeEx = Size_Text_Small;
  shadow = 0;
};

class RscXKeyShadow
{
	type = CT_XKEYDESC;
	idc = -1;
	style = 0;
	h = 0.06;
	size = SizeNormal;
	shadow = 0;
	class Attributes
	{
		font = FontX;
		color = "#C0C1BF";
		align = "left";
	};
	class AttributesImage
	{
		color = "#ffffff";
	};
};

class RscXKey : RscXKeyShadow
{
  class Attributes
  {
		shadow = false;		
	};
};
//Standard map.
class RscMapControl
{
	access = ReadAndWrite;
	type = CT_MAP_MAIN;
	idc = IDC_MAP;
	style = ST_PICTURE;
	shadow = 0;
  // map background
	colorBackground[] = {1, 1, 1, 1};
  // area outside of map
  colorOutside[] = {1, 0, 0, 1}; 
	colorText[] = {0, 0, 0, 1};
	font = FontMAIN;
	sizeEx = Size_Text_Default;
	
	colorSea[] = {0.56, 0.8, 0.98, 0.5};
	colorForest[] = {0.6, 0.8, 0.2, 0.5};
	colorRocks[] = {0.5, 0.5, 0.5, 0.5};
  colorBuildings[] = {0.5, 0.5, 0.5, 1};
	colorCountlines[] = {0.65, 0.45, 0.27, 0.5};
	colorMainCountlines[] = {0.65, 0.45, 0.27, 1};
	colorCountlinesWater[] = {0, 0.53, 1, 0.5};
	colorMainCountlinesWater[] = {0, 0.53, 1, 1};
	colorForestBorder[] = {0.4, 0.8, 0, 1};
	colorRocksBorder[] = {0.5, 0.5, 0.5, 1};
	colorPowerLines[] = {0, 0, 0, 1};
	colorRailWay[] = {0.8, 0.2, 0.3, 1};
	colorNames[] = {0, 0, 0, 1};
	colorInactive[] = {1, 1, 1, 0.5};
	colorLevels[] = {0, 0, 0, 1};
	
	fontLabel = FontMAIN;
	sizeExLabel = Size_Text_Default;
	fontGrid = FontMAIN;
	sizeExGrid = Size_Text_Default;
	fontUnits = FontMAIN;
	sizeExUnits = Size_Text_Default;
	fontNames = FontMAIN;
	sizeExNames = Size_Text_Default;
	fontInfo = FontMAIN;
	sizeExInfo = Size_Text_Default;
	fontLevel = FontMAIN;
	sizeExLevel = Size_Text_Default;
	
	text = ProcTextWhite;
	
	stickX[] = {0.2, {"Gamma", 1, 1.5}};
	stickY[] = {0.2, {"Gamma", 1, 1.5}};
	
	// Map drawing quality coefficients:
	//  units - the width of the screen == 800
	//  limits - size of the landscape square on screen when objects are drawn or single square content is drawn
	
	//@{ coefficients which determine rendering density / threshold
	ptsPerSquareSea = 6;   // seas
	ptsPerSquareTxt = 8;   // textures
	ptsPerSquareCLn = 8;   // count-lines
	ptsPerSquareExp = 8;   // exposure
	ptsPerSquareCost = 8;  // cost
	//@}
	
	//@{ coefficients which determine when rendering of given type is done
	ptsPerSquareFor = 4.0f;   // forests
	ptsPerSquareForEdge = 10.0f;   // forest edges
	ptsPerSquareRoad = 2;  // roads
	ptsPerSquareObj = 10;    // other objects
	//@}

  showCountourInterval = "true";
	
  // _scale is % of map you can see;  satellite map alpha is
  // if map (_scale < alphaFadeStartScale) -> alpha = 1.0 * maxSatelliteAlpha;
  // else map (_scale > alphaFadeEndScale) -> alpha = 0.0;
  // else -> alpha = ((alphaFadeEndScale - _scale) / (alphaFadeEndScale - alphaFadeStartScale)) * maxSatelliteAlpha;  
  maxSatelliteAlpha = 0.66;
  alphaFadeStartScale = 0.05;
  alphaFadeEndScale = 0.15;

	
  class Legend
  {
    x = 0.7;
    y = 0.85;
    w = 0.25;
    h = 0.1;

    font = FontMAIN;
    sizeEx = Size_Text_Default;

    colorBackground[] = {1, 1, 1, 1};
    color[] = {0, 0, 0, 1};
  };

	class ActiveMarker
	{
		color[] = {0.3, 0.1, 0.9, 1};
		size = 50;
	};

	class Command
	{
		color[] = {0, 0.90, 0, 1};
		icon = "#(argb,8,8,3)color(1,1,1,1,co)";
		size = 18;
		importance = 1; // not used
		coefMin = 1; // not used
		coefMax = 1; // not used
	};
  class Task
  {
    icon = ProcTextGreen;
    iconCreated = ProcTextWhite;
    iconCanceled = ProcTextBlue;
    iconDone = ProcTextBlack;
    iconFailed = ProcTextRed;

    colorCreated[] = {1, 1, 1, 1};
    colorCanceled[] = {1, 1, 1, 1};
    colorDone[] = {1, 1, 1, 1};
    colorFailed[] = {1, 1, 1, 1};

    color[] = {1, 1, 1, 1};
    size = 18;
    importance = 1; // not used
    coefMin = 1; // not used
    coefMax = 1; // not used
  };
  class CustomMark
  {
    icon = ProcTextOrange;
    color[] = {1, 1, 1, 1};
    size = 18;
    importance = 1; // not used
    coefMin = 1; // not used
    coefMax = 1; // not used
  };
	class Tree
	{
		color[] = {0.55, 0.64, 0.43, 1};
		icon = "\vbs2\ui\data\map\map_tree_ca.paa";
		size = 16;
		importance = 0.9 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class SmallTree
	{
		color[] = {0.55, 0.64, 0.43, 1};
		icon = "\vbs2\ui\data\map\map_smalltree_ca.paa";
		size = 8;
		importance = 0.6 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Bush
	{
		color[] = {0.55, 0.64, 0.43, 1};
		icon = "\vbs2\ui\data\map\map_bush_ca.paa";
		size = 16;
		importance = 0.2 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Church
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_church_ca.paa";
		size = 16;
		importance = 2 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Chapel
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_chapel_ca.paa";
		size = 16;
		importance = 1 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Cross
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_cross_ca.paa";
		size = 16;
		importance = 0.7 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Rock
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_rock_ca.paa";
		size = 16;
		importance = 1.5 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Bunker
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_bunker_ca.paa";
		size = 16;
		importance = 1.5 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Fortress
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_bunker_ca.paa";
		size = 16;
		importance = 2 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Fountain
	{
		color[] = {0, 0.35, 0.70, 1};
		icon = "\vbs2\ui\data\map\map_fountain_ca.paa";
		size = 16;
		importance = 1 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class ViewTower
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_viewtower_ca.paa";
		size = 16;
		importance = 2.5 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Lighthouse
	{
		color[] = {0.78, 0, 0.05, 1};
		icon = "\vbs2\ui\data\map\map_lighthouse_ca.paa";
		size = 16;
		importance = 3 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Quay
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_quay_ca.paa";
		size = 16;
		importance = 2 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Fuelstation
	{
		color[] = {0, 0, 0, 1};
		icon = "\vbs2\ui\data\map\map_fuelstation_ca.paa";
		size = 16;
		importance = 2 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class Hospital
	{
		color[] = {0.78, 0, 0.05, 1};
		icon = "\vbs2\ui\data\map\map_hospital_ca.paa";
		size = 16;
		importance = 2 * 16 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

	class BusStop
	{
		color[] = {0, 0, 1, 1};
		icon = "\vbs2\ui\data\map\map_busstop_ca.paa";
		size = 8;
		importance = 1 * 8 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
	};

  class Transmitter
  {
		color[] = {0, 0, 1, 1};
		icon = "\vbs2\ui\data\map\map_transmitter_ca.paa";
		size = 8;
		importance = 1 * 8 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
  };

  class Stack
  {
		color[] = {0, 0, 1, 1};
		icon = "\vbs2\ui\data\map\map_stack_ca.paa";
		size = 8;
		importance = 1 * 8 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
  };

  class Ruin
  {
		color[] = {0.78, 0, 0.05, 1};
		icon = "\vbs2\ui\data\map\map_ruin_ca.paa";
		size = 8;
		importance = 1 * 8 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
  };

  class Tourism
  {
		color[] = {0.78, 0, 0.05, 1};
		icon = "\vbs2\ui\data\map\map_tourism_ca.paa";
		size = 8;
		importance = 1 * 8 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
  };

  class Watertower
  {
		color[] = {0, 0.35, 0.70, 1};
		icon = "\vbs2\ui\data\map\map_watertower_ca.paa";
		size = 8;
		importance = 1 * 8 * 0.05; // limit for map scale
		coefMin = 0.25;
		coefMax = 4;
  };

	class Waypoint
	{
		color[] = {0, 0, 0, 1};
		size = 24;
		importance = 1; // not used
		coefMin = 1; // not used
		coefMax = 1; // not used
		icon = "\vbs2\ui\data\map\map_waypoint_ca.paa";
	};

	class WaypointCompleted
	{
		color[] = {0, 0, 0, 1};
		size = 24;
		importance = 1; // not used
		coefMin = 1; // not used
		coefMax = 1; // not used
		icon = "\vbs2\ui\data\map\map_waypoint_completed_ca.paa";
	};
};

class RscObject
{
	access = ReadAndWrite;
	type = CT_OBJECT;
	scale = 1.0;
	direction[] = {0, 0, 1};
	up[] = {0, 1, 0};
  shadow = 0;
};

class RscStandardDisplay
{
	access = ReadAndWrite;
	movingEnable = false;
	enableSimulation = false;
	enableDisplay = false;

	class controlsBackground
	{
		class Background1: RscText
		{
			x = 0; y = 0;
			w = 1; h = 1;
			colorBackground[] = Color_Background;
		};
	};
};

class RscLineBreak 
{
  idc = -1;
  type = CT_LINEBREAK;
  shadow = 0;
};
class RscCompass: RscObject
{
  idc = -1;
  type = CT_OBJECT_ZOOM;
  model = "\core\compass\compass.p3d";
  selectionArrow = "arrow";
  position[] = {0.026, 0.047, 0.20};
  direction[] = {0, 1, 1};

  up[] = {0, 0, -1};
  positionBack[] = {0.0749, -0.059, 0.315};

  inBack = true;
  enableZoom = false;
  zoomDuration = 0.5;

  class Animations
  {
    class Pointer
    {
      type = "rotation";
      source = "compassPointer";
      selection = "kompas";
      axis = "osa kompasu";
      memory = true;
      animPeriod = 0;
      minValue = "rad -180";
      maxValue = "rad 180";
      angle0 = "rad -180";
      angle1 = "rad 180";
    };
    class Arrow
    {
      type = "rotation";
      source = "compassArrow";
      selection = "arrow";
      axis = "osa kompasu";
      memory = true;
      animPeriod = 0;
      minValue = "rad -180";
      maxValue = "rad 180";
      angle0 = "rad -180";
      angle1 = "rad 180";
    };
    class Cover
    {
      type = "rotation";
      source = "compassCover";
      selection = "vicko";
      axis = "osa vicka";
      memory = true;
      animPeriod = 0;
      angle0 = 0;
      angle1 = "rad -81";
    };
  };
};

class RscGPS: RscObject
{
  class Areas
  {
    class Display
    {
      class controls
      {
        class GPSSquare: RscText
        {
          color[]={0,0,0,1};
          style=1;
          idc=75;
          x=0;
          y=-0.250000;
          w=1;
          h=1;
          sizeEx=0.220000;
          text="";
        };
        class GPSSquareExt: RscText
        {
          color[]={0,0,0,1};
          style=1;
          idc=77;
          x=0;
          y=0.150000;
          w=1;
          h=1;
          sizeEx=0.220000;
          text="";
        };
      };
      selection="display";
    };
  };
  idc=-1;
  type=CT_OBJECT_ZOOM;
  model="\vbs2\ui\data\gps\gps.p3d";
  enableZoom=1;
  zoomDuration=1;
  scale=0.600000;
  waitForLoad=0;
  inBack = true;
  x=0.8;
  xBack=0.8;
  y=0.992000;
  yBack=0.992000;
  z=0.300000;
  zBack=0.220000;
};

class RscWatch: RscObject
{
  idc = -1;
  type = CT_OBJECT_ZOOM;
  model = "\core\watch\watch.p3d";
  selectionDate1 = "date1";
  selectionDate2 = "date2";
  selectionDay = "day";
  position[] = {0.026, 0.047, 0.20};
  positionBack[] = {0.05, -0.05, 0.22};
  inBack = true;
  enableZoom = true;
  zoomDuration = 0.5;

  class Animations
  {
    class WatchHour
    {
      type = "rotation";
      source = "clockHour";
      selection = "hodinova";
      axis = "osa";
      memory = true;
      animPeriod = 0;
      angle0 = 0;
      angle1 = "rad 360";
    };
    class WatchMinute
    {
      type = "rotation";
      source = "clockMinute";
      selection = "minutova";
      axis = "osa";
      memory = true;
      animPeriod = 0;
      angle0 = 0;
      angle1 = "rad 360";
    };
    class WatchSecond
    {
      type = "rotation";
      source = "clockSecond";
      selection = "vterinova";
      axis = "osa";
      memory = true;
      animPeriod = 0;
      angle0 = 0;
      angle1 = "rad 360";
    };
  };
};
//In-game GPS minimap
class RscMiniMap
{
	access = ReadAndWrite;
	idd = IDD_MINIMAP;
	movingEnable = false;
	enableSimulation = true;
	enableDisplay = true;
	
	class controls 
	{
		class MiniMap: RscMapControl 
		{
			IDC = IDC_MINIMAP;
			x = 0.1;
			y = 0.1;
			w = 0.3;
			h = 0.3;
      showCountourInterval = "false";
		};
	};
};

//In-game GPS minimap small
class RscMiniMapSmall: RscMiniMap {};

class RscButtonImages
{
	class ControllerS {};
};

class RscObjectives
{
  access = ReadAndWrite;
  done = ProcTextWhite;
  failed = ProcTextWhite;
  active = ProcTextWhite;
  cancled = ProcTextWhite;
};

