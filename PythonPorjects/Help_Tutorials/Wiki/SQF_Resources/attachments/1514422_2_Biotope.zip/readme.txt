Example biotope file, to create snow.
Works on any map, but the Takistan map is optimized for snow, so it's best tested there.

Place in VBS installation folder, and activate via {loadBiotope "snow.sx"}.