if (isNil "BP_placeTypes") then {
	BP_placeTypes = [
		["houses",	0],
		["forest", 	1],
		["trees",   1],
		["meadow", 	1],
		["hills",  	1],			
		["sea",    	1],			
		["deadBody",1],		
		["rain",   	1],		
		["windy",  	1],		
		["night",   1]
	];
};


_radiusOptions = [10,50,200,500];

_precisionOptions = [5,10,20,50];