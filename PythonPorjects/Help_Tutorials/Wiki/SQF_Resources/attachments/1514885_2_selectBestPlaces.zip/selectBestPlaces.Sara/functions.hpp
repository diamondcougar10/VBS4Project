
_makeMarker = {
	private ["_pos","_color","_nametext","_type","_size","_shape","_autosize","_idx","_text"];

	if (count _this==0) exitWith {
		_idx = 0;
		while {true} do {
			_idx = _idx + 1;
			_markername = format["mrk_%1",_idx];
			if ((getMarkerPos _markername select 0)==0) exitWith {};
			deleteMarker _markername;
		};
		BP_MarkerCount = 0;
	};
	
	_pos = _this select 0;
	
	_color = "ColorRed";
	_alpha = 1;
	if (count _this>1) then {
		_color = _this select 1;
		if (typeName _color=="ARRAY") then {
			_alpha = _color select 1;
			_color = _color select 0;
		};
	};
	_nametext = if (count _this>2) then {_this select 2} else {""};
	_type = if (count _this>3) then {_this select 3} else {"IK23"};
	_size = if (count _this>4) then {_this select 4} else {.5};
	_shape = if (count _this>5) then {_this select 5} else {"ICON"};
	_autosize = if (count _this>6) then {_this select 6} else {false};
	
	if (typeName _pos=="OBJECT") then {
		_pos = getPos _pos;
	};
	
	if (isNil "BP_MarkerCount") then {
		BP_MarkerCount=0;
	};
	BP_MarkerCount=BP_MarkerCount+1;
	
	_markername = format["mrk_%1",BP_MarkerCount];
	_text = "";
	if (typeName _nametext=="ARRAY") then {
		_markername = _nametext select 0;
		_text = _nametext select 1;
	} else {
		_text = _nametext;
	};
	
	_markerobj = createMarker[_markername,_pos];
	_markername setMarkerShape _shape;
	if (_shape=="ICON") then {
		_markername setMarkerType _type;
	};
	_markername setMarkerSize [_size, _size];
	_markername setMarkerColor _color;
	_markername setMarkerAlpha _alpha;
	_markername setMarkerText _text;
	_markername setMarkerAutoSize _autosize;
};	


_getCondition = {
	private ["_listYes","_listNo","_mult","_plus","_text","_condition"];
	_listYes = _this select 0;
	_listNo = _this select 1;
	
	_condition = "";
	_mult = "";
	for "_i" from 0 to (lbSize _listYes)-1 do {
		_text = _listYes lbText _i;
		_plus = if (_condition!="") then {" + "} else {""};
		_condition = format["%1%2%3",_condition,_plus,_text];
		_mult = " * ";
	};
	for "_i" from 0 to (lbSize _listNo)-1 do {
		_text = _listNo lbText _i;
		_condition = format["%1%2(1 - %3)",_condition,_mult,_text];
		_mult = " * ";
	};
	_condition
};


_updList = {
	private ["_lists","_type","_list"];
	_lists = _this select 0;
	// go through all types
	for "_t" from 0 to (count BP_placeTypes)-1 do {
		_type = (BP_placeTypes select _t) select 0;
		// go through all lists
		for "_l" from 0 to 2 do {
			_list = _lists select _l;
			// go through all list entries
			for "_i" from 0 to (lbSize _list)-1 do {
				if (_type==_list lbText _i) exitWith {
					BP_placeTypes set [_t,[_type,_l]];
					_l = 2;
				};
			};
		};
	};
};
