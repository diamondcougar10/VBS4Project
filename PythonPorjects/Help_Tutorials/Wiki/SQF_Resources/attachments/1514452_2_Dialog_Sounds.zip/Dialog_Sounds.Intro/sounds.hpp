// sounds included in the mission, 
// and referred to by their class name (in the 'playSound' command) 
class CfgSounds {
 sounds[] = {};   
  class beep {
		name = "";
		sound[] = {"\sounds\beep.ogg", 20, 1};
		titles[] = {};
  };
  class boing {
		name = "";
		sound[] = {"\sounds\boing.ogg", 20, 1};
		titles[] = {};
  };
  class whistle {
		name = "";
		sound[] = {"\sounds\whistle.wav", 20, 1};
		titles[] = {};
  };
};


