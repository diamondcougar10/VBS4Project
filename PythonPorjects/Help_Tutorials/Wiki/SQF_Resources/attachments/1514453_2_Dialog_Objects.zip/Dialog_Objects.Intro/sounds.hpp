class CfgSounds {
	sounds[] = {};   
	class beep {
		name = "";
		sound[] = {"beep.ogg", 1000, 1};
		titles[] = {};
	};
};


