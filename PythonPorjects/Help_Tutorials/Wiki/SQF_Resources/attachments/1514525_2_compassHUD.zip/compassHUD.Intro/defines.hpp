// IDCs used for controls
#define IDC_LABEL 20000
#define IDC_LINE 20001
#define IDC_ARMLEFT 20002
#define IDC_ARMRIGHT 20003


// position and size of HUD
#define LEFT .01
#define TOP .8
#define WIDTH .14

// length of compass line
#define LINELENGTH .07
// length of arrow arms
#define ARROWLENGTH .02
