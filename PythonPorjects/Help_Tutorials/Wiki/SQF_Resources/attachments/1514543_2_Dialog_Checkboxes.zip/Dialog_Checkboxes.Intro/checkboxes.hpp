__EXEC (_x=.32; _top=.6;_y=_top; _w=.16);

// dialog using checkboxes
class Dlg1 {
  idd = 20000;
  movingEnable = 1;

  objects[] = {};

  class controls {
	  class LISTLABEL1 : RscText {
	  	x = __EVAL(_x-.004);
	  	y = __EVAL(_y);
	  	w = __EVAL(_w);
	  	h = 0.032;
	  	sizeEx = 0.036;
	  	text = "Select animals";
	  };
	  __EXEC (_y=_y+.036);
	  
	  // label for first selection item
	  class ITEM1_TXT : RscText {
	  	x = __EVAL(_x);
	  	y = __EVAL(_y);
	  	w = __EVAL(_w);
			h = 0.034;
	  	sizeEx = 0.03;
			text = "Goat";
	  };
	  // checkbox for first selection item
	  class ITEM1_CHK : RscActiveText {
	  	idc = 20001;
			style = ST_PICTURE + ST_KEEP_ASPECT_RATIO;
	  	x = __EVAL(_x+_w-.03);
	  	y = __EVAL(_y+.004);
	  	w = 0.024;
			h = 0.024;
			sizeEx = .024;
			color[] = {1, 1, 1, 1};
			colortext[] = {0, 0, 0, 0};
			// by default, display an empty checkbox
			text = "img\chkbox_empty.paa";
			// if the control is clicked, swap the currently displayed image
	  	action = "_txt=ctrlText (_this select 0); _txt = if ('empty' in _txt) then {'checked'} else {'empty'}; (_this select 0) ctrlSetText 'img\chkbox_'+_txt+'.paa';";
	  };
	  __EXEC (_y=_y+.036);
	  
	  // label & radio button for second selection item
	  class ITEM2_TXT : ITEM1_TXT {
	  	y = __EVAL(_y);
			text = "Cow";
	  };
	  class ITEM2_CHK : ITEM1_CHK {
	  	idc = 20002;
	  	y = __EVAL(_y+.004);
	  };
	  __EXEC (_y=_y+.036);
	  
	  // label & radio button for third selection item
	  class ITEM3_TXT : ITEM1_TXT {
	  	y = __EVAL(_y);
			text = "Dog";
	  };
	  class ITEM3_CHK : ITEM1_CHK {
	  	idc = 20003;
	  	y = __EVAL(_y+.004);
	  };
	  __EXEC (_y=_y+.05);
	  
	  // "submit" button	  
	  class ACTION : RscButton {
	  	idc = -1;
			style = ST_CENTER;
	  	x = __EVAL(_x);
	  	y = __EVAL(_y);
	  	w = __EVAL(_w);
			h = 0.034;
			text = "Create animals";
	  	action = "doit=true";
	  };
	  __EXEC (_y=_y+.036);
	};

	// background
	class controlsBackground {
	  class FORM_BACKGROUND : RscText {
	  	moving = 1;
	  	x = __EVAL(_x-.01);
	  	y = __EVAL(_top-.01);
	  	w = __EVAL(_w+.02);
	  	h = __EVAL((_y-_top)+.02);
			colorBackground[] = {0.8, 0.8, 0.8, 0.7};
	    text = "";
	  };
	};
};
