__EXEC (_x=.52; _top=.6;_y=_top; _w=.16);

// dialog using radio buttons
class Dlg2 {
  idd = 20000;
  movingEnable = 1;

  objects[] = {};

  class controls {
	  class LISTLABEL1 : RscText {
	  	x = __EVAL(_x);
	  	y = __EVAL(_y);
	  	w = __EVAL(_w);
	  	h = 0.032;
	  	sizeEx = 0.036;
	  	text = "Select animal";
	  };
	  __EXEC (_y=_y+.036);
	  
	  // label for first selection item
	  class ITEM1_TXT : RscText {
	  	x = __EVAL(_x);
	  	y = __EVAL(_y);
	  	w = __EVAL(_w);
			h = 0.034;
	  	sizeEx = 0.03;
			text = "Goat";
	  };
	  // radio button for first selection item
	  class ITEM1_CHK : RscActiveText {
	  	idc = 20001;
			style = ST_PICTURE + ST_KEEP_ASPECT_RATIO;
	  	x = __EVAL(_x+_w-.03);
	  	y = __EVAL(_y+.004);
	  	w = 0.024;
			h = 0.024;
			sizeEx = .024;
			color[] = {1, 1, 1, 1};
			colortext[] = {0, 0, 0, 0};
			// by default, display an empty radio button
			text = "img\radio_empty.paa";
			// if the control is clicked, call the radio script with a list of ALL IDCs of the related radio buttons
	  	action = "[_this,[20001,20002,20003]] execVM 'img\radio.sqf';";
	  };
	  __EXEC (_y=_y+.036);

	  // label & radio button for second selection item
	  class ITEM2_TXT : ITEM1_TXT {
	  	y = __EVAL(_y);
			text = "Cow";
	  };
	  class ITEM2_CHK : ITEM1_CHK {
	  	idc = 20002;
	  	y = __EVAL(_y+.004);
	  };
	  __EXEC (_y=_y+.036);
	  
	  // label & radio button for third selection item
	  class ITEM3_TXT : ITEM1_TXT {
	  	y = __EVAL(_y);
			text = "Dog";
	  };
	  class ITEM3_CHK : ITEM1_CHK {
	  	idc = 20003;
	  	y = __EVAL(_y+.004);
	  };
	  __EXEC (_y=_y+.05);
	  
	  // "submit" button	  
	  class ACTION : RscButton {
	  	idc = -1;
			style = ST_CENTER;
	  	x = __EVAL(_x);
	  	y = __EVAL(_y);
	  	w = __EVAL(_w);
			h = 0.034;
			text = "Create animal";
	  	action = "doit=true";
	  };
	  __EXEC (_y=_y+.036);
	};

	// background
	class controlsBackground {
	  class FORM_BACKGROUND : RscText {
	  	moving = 1;
	  	x = __EVAL(_x-.01);
	  	y = __EVAL(_top-.01);
	  	w = __EVAL(_w+.02);
	  	h = __EVAL((_y-_top)+.02);
			colorBackground[] = {0.8, 0.8, 0.8, 0.7};
	    text = "";
	  };
	};
};
