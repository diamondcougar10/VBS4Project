

_getCmdIdx = {
	private ["_type","_properties","_parms","_idx","_xEff"];
	_type = _this select 0;

	_idx = -1;
	for "_i" from 0 to (count Parameters)-1 do {
		if (_type==(Parameters select _i) select 0) exitWith {
			_idx = _i;
		};
	}forEach Parameters;
	_idx
};


// populate the global Parameters array with their default values
// which are later updated with the actual slider/button values
// if either an effect handle or an array of properties is passed, use those instead
_resetCmdArray = {
	private ["_type","_effect","_parms","_properties","_set","_xEff"];
	_type = _this select 0;
	_effect = if (count _this>1) then {_this select 1} else {0};
	_parms = if (count _this>2) then {_this select 2} else {[]};
	
	_properties = [];
	// find the appropritate effect definition in CommandProperties
	{
		if (_type==_x select 0) exitWith {
			_properties = _x;
		};
	}forEach CommandProperties;

	// get the property default values
	for "_i" from 1 to (count _properties)-1 do {
		if (count _parms<_i) then {
			_parms = _parms + [(_properties select _i) select 3];
		};
	};
	// find the matching entry in Parameters
	_idx = [_type] call _getCmdIdx;
	if (_idx!=-1) then {
		Parameters set [_idx,[_type,_effect,_parms]];
	} else {
		Parameters = Parameters + [[_type,_effect,_parms]];
	};
	//echo format["[K] reset %1: %2",_properties select 0, _parms];
};


_showSlider = {
	private ["_show","_useSlider","_label","_slider","_button","_pos"];
	_show = _this select 0;
	_useSlider = _this select 1;
	_label = _this select 2;
	_slider = _this select 3;
	_button = _this select 4;
	{
		_pos = ctrlPosition _x;
		_posY = abs(_pos select 1);
		if !(_show) then {
			_posY = _posY * -1;
		};			
		_pos set [1,_posY];
		_x ctrlSetPosition _pos;
		_x ctrlCommit 0;
		_x ctrlShow _show;
	}forEach [_label,_slider,_button];
	_slider ctrlShow _useSlider;
	_button ctrlShow !(_useSlider);
};


// read the default assignments for the specified effect type
_getCmdDefs = {
	private ["_cmdType","_cmdDefs","_cmdProperty"];
	_cmdType = _this select 0;
	
	// load the selected effect definition from the effects array (for labeling the controls)
	for "_i" from 0 to (count CommandProperties)-1 do {
		_cmdProperty = CommandProperties select _i;
		if (_cmdProperty select 0==_cmdType) exitWith {
			_cmdDefs = _cmdProperty;
		};
	}forEach CommandProperties;
	_cmdDefs
};


// read the slider/button values, and return them as a flat array
_readSliders = {
	private ["_effDefs","_display","_idc","_sliderVals","_ctrlSlider","_ctrlButton","_val"];
	_effDefs = _this select 0;
	_display = _this select 1;
	
	_sliderVals = [];
	for "_i" from 0 to (count _effDefs)-2 do {
		_idc = 20003 + _i*3;
		_ctrlSlider = _display displayCtrl (_idc+1);
		_ctrlButton = _display displayCtrl (_idc+2);
		_val = sliderPosition _ctrlSlider;
		// parameter is boolean (control is active text), so use the true/false caption
		if (typeName ((_effDefs select _i+1) select 1)=="BOOL") then {
			_val = (ctrlText _ctrlButton=="true");
		};
		_sliderVals = _sliderVals + [_val];
	};
	//echo format["[K] %1, %2",count _effDefs,_sliderVals];
	_sliderVals
};


// converts a flat array (e.g. with values from sliders)
// into a nested array, with sub-array appropriate for the effect type
_createCmdArray = {
	private ["_effDefs","_parms","_effParms","_arrDef","_subArr"];
	_effDefs = _this select 0;
	_parms = _this select 1;
	
	_effParms = [];
	_subArr = [];	
	for "_i" from 0 to (count _effDefs)-1 do {
		_val = _parms select _i;
		if (typeName _val=="SCALAR") then {
			_val = [_parms select _i,4] call fn_vbs_cutDecimals;
		};
		// parameter is part of an array, so create a temp array first, 
		// and once the final element has been read, enter it into the argument
		if (count (_effDefs select _i+1)>4) then {
			_arrDef = (_effDefs select _i+1) select 4;
			_subArr set [(_arrDef select 1)-1,_val];
			if (_arrDef select 1==_arrDef select 0) then {
				_effParms = _effParms + [_subArr];
				_subArr = [];
			};
		} else {
			_effParms = _effParms + [_val];
		};
	};
	_effParms
};	


// goes through an array, and trims all numbers to the specified decimal digits
_cutDecimals = {
	private ["_inArr","_len","_val","_outArr"];
	_inArr = _this select 0;
	_len = _this select 1;
	_outArr = [];
	{
		_val = _x;
		if (typeName _x=="SCALAR") then {
			_val = [_val,_len] call fn_vbs_cutDecimals;
		};
		_outArr = _outArr + [_val];
	}forEach _inArr;
	_outArr
};


// converts an element from an array entered as a string into either a number or a boolean
_getVal = {
	private ["_string","_val"];
	_string = _this select 0;
	_val = parseNumber _tmpVal;
	if (_string=="true") then {
		_val = true;
	};
	if (_string=="false") then {
		_val = false;
	};
	_val
};

// creates an array out of a string, keeping any sub-arrays
_strToArr = {
	private ["_string","_outArr","_tmpArr","_tmpVal","_isArr"];
	_arrArr = toArray _arrstr;
	_outArr = [];
	_tmpArr = [];
	_tmpVal = "";
	_isArr = false;
	for "_i" from 1 to (count _arrArr)-2 do {
		_asc = _arrArr select _i;
		switch (_asc) do {
			// comma
			case 44: {
				if (_tmpval!="") then {
					_val = [_tmpVal] call _getVal;
					if (_isArr) then {
						_tmpArr = _tmpArr + [_val];
					} else {
						_outArr = _outArr + [_val];
						_tmpArr = [];
						_isArr = false;
					};
				};
				_tmpVal = "";
			};
			// bracket open "["
			case 91: {
				_isArr = true;
			};
			// bracket close "]"
			case 93: {
				_val = [_tmpVal] call _getVal;
				_tmpArr = _tmpArr + [_val];
				_outArr = _outArr + [_tmpArr];
				_isArr = false;
				_tmpVal = "";
			};
			default {
				_tmpVal = _tmpVal + toString([_asc]);
			};
		};
	};
	if (_tmpVal!="") then {
		_outArr = _outArr + [[_tmpVal] call _getVal];
	};
	_outArr
};


// creates an array out of a string, making sub-array elements part of the top-level array
_strToArr1 = {
	private ["_string","_outArr","_tmpArr","_tmpVal","_isArr"];
	_arrArr = toArray _arrstr;
	_outArr = [];
	_tmpArr = [];
	_tmpVal = "";
	_isArr = false;
	for "_i" from 1 to (count _arrArr)-2 do {
		_asc = _arrArr select _i;
		switch (_asc) do {
			// space: ignore
			case 32: {};
			// bracket open "[" : ignore
			case 91: {};
			// bracket close "]" : ignore
			case 93: {};
			// comma: store the previously collected digits
			case 44: {
				_val = [_tmpVal] call _getVal;
				_outArr = _outArr + [_val];
				_tmpVal = "";
			};
			// numbers, decimal points : collect until next comma is found
			default {
				_tmpVal = _tmpVal + toString([_asc]);
			};
		};
	};
	if (_tmpVal!="") then {
		_outArr = _outArr + [[_tmpVal] call _getVal];
	};
	_outArr
};