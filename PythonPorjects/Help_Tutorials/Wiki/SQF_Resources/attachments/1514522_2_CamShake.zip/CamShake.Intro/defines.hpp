/*
	Effect/Command name
	parameters, range, default, [x,y]: if 4th argument exists then submit as in position y of an array with x elements
	...
	priorities will be assinged in the order the effects are listed here (i.e. the first one will be 1000, next one 900, etc.)
*/
	
if (isNil "CommandProperties") then {
	CommandProperties = [
		["addCamShake",
			["power", 					0,20, 		5],
			["duration", 				0,10, 		2],
			["frequency", 			0,100, 		20]
		],
	// does not seem to do anything 
	/*
		["setCamShakeDefParams",
			["power", 					0,20, 		12],
			["duration", 				0,10, 		1],
			["frequency", 			0,200, 		120],
			["minSpeed", 				0,50, 		20],
			["minMaxx", 				0,5, 			0],
			["caliberCoefHit", 	0,20000, 	10000],
			["vehicleCoef", 		0,1, 			0.5],
			["caliberCoefFire", 0,1, 			0.2],
			["vehicleCoef", 		0,.1, 		0.05]
		],
	*/
		["setCamShakeParams",
			["posCoef",  				0,.2, 			0.1],
			["vertCoef", 				0,10, 			1.0],
			["horzCoef", 				0,10, 			1.0],
			["bankCoef", 				0,20, 			5.0],
			["interpolation", 	true,false, true]
		]
	];
};



// execute the appropriate command, with the properties read from the sliders,
// and store the properties in the global array
_executeCmd = {
	private ["_action","_command","_cmdIdx","_cmdType","_cmdParms","_ret","_args"];
	_action = _this select 0;
	_cmdIdx = _this select 1;
	_cmdType = _this select 2;
	_cmdParms = _this select 3;

	_command = (Parameters select _cmdIdx) select 1;
	
	_ret = "";
	switch (_action) do {
		// effect sliders have changed
		case 1: {
			switch (_cmdType) do {
				case "setCamShakeDefParams": {
					setCamShakeDefParams _cmdParms;
				};
				case "setCamShakeParams": {
					setCamShakeParams _cmdParms;
				};
			};
			//echo format["[K] set '%1' to %2",_cmdType,_cmdParms];
			// save the values
			Parameters set [_cmdIdx,[_cmdType,_command,_cmdParms]];
		};
		
		// apply button has been pressed
		case 2: {
			// if we're not currently showing the addCamShake sliders, then read their values from the Parameters array
			if (_cmdType!="addCamShake") then {
				for "_i" from 0 to (count Parameters)-1 do {
					if ((Parameters select _i) select 0=="addCamShake") exitWith {
						_cmdParms = (Parameters select _i) select 2;
						_cmdIdx = _i;
					};
				};
			};
			enableCamShake true;
			addCamShake _cmdParms;
			//echo format["[K] set '%1' (%2) to %3",_cmdType,_command,_cmdParms];
		};
		
		// reset/stop effect
		case 3: {
			enableCamShake false;
		};
		
		// output for HUD
		case 9: {
			_ret = format['%1 %2',_cmdType,[_cmdParms,4] call _cutDecimals];
		};
	};
	
	_ret
};