#define EVENTS [	\
	"ButtonClick",	\
	"ButtonDown",	\
	"ButtonUp",	\
	"Char",	\
	"CheckBoxesSelChanged",	\
	"ChildDestroyed",	\
	"Destroy",	\
	"HTMLLink",	\
	"IMEChar",	\
	"IMEComposition",	\
	"JoystickButton",	\
	"KeyDown",	\
	"KeyUp",	\
	"KillFocus",	\
	"LBDblClick",	\
	"LBDrag",	\
	"LBDragging",	\
	"LBDrop",	\
	"LBListSelChanged",	\
	"LBSelChanged",	\
	"Load",	\
	"MenuSelected",	\
	"MouseButtonClick",	\
	"MouseButtonDblClick",	\
	"MouseButtonDown",	\
	"MouseButtonUp",	\
	"MouseEnter",	\
	"MouseExit",	\
	"MouseHolding",	\
	"MouseMoving",	\
	"MouseZChanged",	\
	"ObjectMoved",	\
	"SetVisible",	\
	"SetFocus",	\
	"SliderPosChanged",	\
	"Timer",	\
	"ToolBoxSelChanged",	\
	"TreeLButtonDown",	\
	"TreeMouseHold",	\
	"TreeMouseMove",	\
	"TreeMouseExit",	\
	"TreeSelChanged",	\
	"TreeDblClick",	\
	"TreeExpanded",	\
	"TreeCollapsed",	\
	"StateBoxToggle",	\
	"Unload"	\
]

#define IDC_LISTBOXN 20015
#define IDC_STATEBOX 20016
#define IDC_ADV_TREE 20017
#define IDC_SECTVIEW 20018

#define INTRODUCED [	\
	[IDC_LISTBOXN,2.0],	\
	[IDC_STATEBOX,3.4],	\
	[IDC_ADV_TREE,3.4],	\
	[IDC_SECTVIEW,3.6]	\
]
