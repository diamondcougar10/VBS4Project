class vbs_weaponElevationHUD
{
	idd       = IDD_WPNHUD_INFO;
	onLoad = "GUNNER_INFO_DISP = (_this select 0)";
	duration = 1e10;

	#define DLG_W          (GUI_GRID_W * 16)   // Width of the dialog (excludes buttons)
	#define DLG_X          ((1 - DLG_W) * 0.5) // X position of the dialog

	#define TITLE_H        GUI_GRID_H          // Height of the title

	#define LINE_H         GUI_GRID_H          // Height of each option line
	#define LINES_NUM      4                   // Number of option lines

	#define SPACE_X        (GUI_GRID_W * 0.25) // Space between start/end of the dialog and content in X
	#define SPACE_Y        (GUI_GRID_H * 0.5)  // Space between start/end of the dialog and content in Y

	#define DLG_H          (TITLE_H + SPACE_Y + LINE_H * LINES_NUM + SPACE_Y) // Height of the dialog
	#define DLG_Y          (safeZoneY + safeZoneH - DLG_H - GUI_GRID_H)       // Y position of the dialog

	#define LABEL_X        (DLG_X + SPACE_X)            // X position of the first label
	#define LABEL_Y        (DLG_Y + TITLE_H + SPACE_Y)  // Y position of labels
	#define LABEL_W        (GUI_GRID_W * 4)             // Width of each label

	#define VALUE_H        (GUI_GRID_H * 0.75)                   // Height of each value control
	#define VALUE_X        (LABEL_X + LABEL_W)                   // X position of values
	#define VALUE_Y_OFFSET ((LINE_H - VALUE_H) * 0.5)            // Offset between value and label Y
	#define VALUE_Y        (LABEL_Y + VALUE_Y_OFFSET)            // Y position of the first value
	#define VALUE_W        (DLG_W - (VALUE_X - DLG_X) - SPACE_Y) // Width of each value control

	#define VALUE_EXTRA_W  (GUI_GRID_W * 1.5) // Width of the extra value on the right

	#define BUTTON_W       (GUI_GRID_W * 4) // Width of buttons
	#define BUTTON_H       GUI_GRID_H       // Height of each button

	#define TRAV_X (0.5 - (GUI_GRID_W * 11.75) / 2)
	#define TRAV_Y (safeZoneY + safeZoneH - GUI_GRID_H * 3.4)
	#define TRAV_W (GUI_GRID_W * 10)
	#define TRAV_H (GUI_GRID_H * 2.4)

	#define ELEV_X (safeZoneX + safeZoneW - GUI_GRID_W * 3.4)
	#define ELEV_Y (GUI_GRID_H * 5)
	#define ELEV_W (GUI_GRID_W * 2.4)
	#define ELEV_H (GUI_GRID_H * 10)

	class ControlsBackground
	{
		class backgroundElev : vbs3_menu_blackBackground
		{
			x           = ELEV_X;
			y           = ELEV_Y;
			w           = ELEV_W;
			h           = GUI_GRID_H * 10 + GUI_GRID_H * 1.5;
		};

		class backgroundTrav : backgroundElev
		{
			x           = TRAV_X;
			y           = TRAV_Y;
			w           = GUI_GRID_W * 11.75;
			h           = GUI_GRID_H * 2.4;
		};
	};

	class Controls
	{
		class traverseSlider : RscSlider
		{
			idc                 = IDC_WPNHUD_TRAV_SLIDER;
			x                   = TRAV_X + GUI_GRID_W;
			y                   = TRAV_Y + GUI_GRID_H;
			w                   = TRAV_W - (GUI_GRID_W * 2);
			h                   = VALUE_H;
			type                = CT_SLIDER;
			style               = SL_HORZ + LB_TEXTURES;
			color[]             = VBS3_COLOR_LIGHTEST;
			coloractive[]       = VBS3_COLOR_LIGHTEST;
		};

		class elevationSlider : RscSlider
		{
			idc                 = IDC_WPNHUD_ELEV_SLIDER;
			x                   = ELEV_X + GUI_GRID_W;
			y                   = ELEV_Y + GUI_GRID_H;
			w                   = GUI_GRID_W * 0.75;
			h                   = ELEV_H - (GUI_GRID_H *2);
			type                = CT_SLIDER;
			style               = SL_VERT + LB_TEXTURES;
			color[]             = VBS3_COLOR_LIGHTEST;
			coloractive[]       = VBS3_COLOR_LIGHTEST;
		};

		class elevationLabel : vbs3_menu_text
		{
			idc         = IDC_WPNHUD_ELEV_LABEL;
			x           = ELEV_X + (GUI_GRID_W * 0.5);
			y           = ELEV_Y + GUI_GRID_H + ELEV_H - (GUI_GRID_H * 1.25);
			h           = LINE_H;
			w           = GUI_GRID_W * 1.5;
			style       = ST_WITH_RECT + ST_CENTER;
			text        = "9999";
		};

		class traverseLabel : elevationLabel
		{
			idc         = IDC_WPNHUD_TRAV_LABEL;
			x           = TRAV_X + (GUI_GRID_W * 1.5) + (TRAV_W - (GUI_GRID_W * 2));
			y           = TRAV_Y + GUI_GRID_H * 0.8;
			h           = LINE_H;
			w           = GUI_GRID_W * 1.5;
			style       = ST_WITH_RECT + ST_CENTER;
			text        = "9999";
		};
	};
};