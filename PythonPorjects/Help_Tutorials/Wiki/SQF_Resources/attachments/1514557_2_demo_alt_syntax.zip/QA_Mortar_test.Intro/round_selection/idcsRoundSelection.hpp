
#define IDC_MORTAR_WEAPON               88880
#define IDC_MORTAR_AMMO                 88881
#define IDC_MORTAR_FUSE                 88882
#define IDC_MORTAR_CHARGE               88883
#define IDC_MORTAR_PROXIMITY_LABEL      88884
#define IDC_MORTAR_PROXIMITY_LABEL_UNIT 888841
#define IDC_MORTAR_PROXIMITY            88885
#define IDC_MORTAR_FUSETIME_LABEL       88886
#define IDC_MORTAR_FUSETIME             88887
#define IDC_MORTAR_BUTTON_OK            88889
#define IDC_MORTAR_BUTTON_CANCEL        88888
