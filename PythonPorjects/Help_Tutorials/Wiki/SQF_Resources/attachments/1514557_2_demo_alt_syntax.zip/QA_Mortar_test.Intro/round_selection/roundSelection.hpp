#include "idcsRoundSelection.hpp"

#define DLG_GLOBAL_W   11

#define DLG_W          (GUI_GRID_W * 12)   // Width of the dialog (excludes buttons)
#define DLG_X          ((1 - DLG_W) * 0.5) // X position of the dialog

#define TITLE_H        GUI_GRID_H          // Height of the title

#define LINE_H         GUI_GRID_H          // Height of each option line
#define LINES_NUM      6                   // Number of option lines

#define SPACE_X        (GUI_GRID_W * 0.25) // Space between start/end of the dialog and content in X
#define SPACE_Y        (GUI_GRID_H * 0.5)  // Space between start/end of the dialog and content in Y

#define DLG_H          (TITLE_H + SPACE_Y + LINE_H * LINES_NUM + SPACE_Y) // Height of the dialog
#define DLG_Y          (safeZoneY + safeZoneH - DLG_H - GUI_GRID_H)       // Y position of the dialog

#define LABEL_X        (DLG_X + SPACE_X)            // X position of the first label
#define LABEL_Y        (DLG_Y + TITLE_H + SPACE_Y)  // Y position of labels
#define LABEL_W        (GUI_GRID_W * 4)             // Width of each label

#define VALUE_H        (GUI_GRID_H * 0.75)                   // Height of each value control
#define VALUE_X        (LABEL_X + LABEL_W)                   // X position of values
#define VALUE_Y_OFFSET ((LINE_H - VALUE_H) * 0.5)            // Offset between value and label Y
#define VALUE_Y        (LABEL_Y + VALUE_Y_OFFSET)            // Y position of the first value
#define VALUE_W        (DLG_W - (VALUE_X - DLG_X) - SPACE_Y) // Width of each value control

#define VALUE_EXTRA_W  (GUI_GRID_W * 1.5) // Width of the extra value on the right

#define BUTTON_W       (GUI_GRID_W * 4) // Width of buttons
#define BUTTON_H       GUI_GRID_H       // Height of each button

#define DLG_W_W        (GUI_GRID_W * 11)
#define DLG_X_W        ((1 - DLG_W_W) * 0.5)                       // X position of the dialog
#define LABEL_X_W      (DLG_X_W + SPACE_X)                         // X position of the first label
#define VALUE_X_W      (LABEL_X_W + LABEL_W)                       // X position of values
#define VALUE_W_W      (DLG_W_W - (VALUE_X_W - DLG_X_W) - SPACE_Y) // Width of each value control

// Mortar Ammo Selection dlg
class MortarOptions
{
	idd = IDD_MORTAR_OPTIONS;
	onLoad = "_this call 'round_selection\initRoundSelection.sqf'";

	class ControlsBackground
	{
		class Background1 : vbs3_menu_blackBackground
		{
			x           = DLG_X_W;
			y           = DLG_Y;
			w           = DLG_W_W;
			h           = DLG_H;
		};

		class Title1 : vbs3_menu_titleText
		{
			x           = DLG_X_W;
			y           = DLG_Y;
			w           = DLG_W_W;
			h           = TITLE_H;
			text        = "Mortar Round Settings";
			style       = ST_UPPERCASE;
		};

		class AmmunitionLabel : vbs3_menu_text
		{
			x           = LABEL_X_W;
			y           = LABEL_Y;
			w           = LABEL_W;
			text        = "Ammo Type";
		};

		class FuseLabel : AmmunitionLabel
		{
			y           = LABEL_Y + LINE_H;
			text        = "Fuse Type";
		};

		class ProximityLabel : AmmunitionLabel
		{
			idc         = IDC_MORTAR_PROXIMITY_LABEL;
			y           = LABEL_Y + LINE_H*2;
			text        = "Proximity Distance";
		};

		class ProximityLabelUnit : AmmunitionLabel
		{
			idc         = IDC_MORTAR_PROXIMITY_LABEL_UNIT;
			x           = DLG_X_W + LABEL_W + GUI_GRID_W * 1.25 + GUI_GUTTER_W;
			y           = LABEL_Y + LINE_H * 2;
			w           = GUI_GRID_W;
			text        = "m";
		};

		class FuseTimeLabel : AmmunitionLabel
		{
			idc         = IDC_MORTAR_FUSETIME_LABEL;
			y           = LABEL_Y + LINE_H*2;
			text        = "Delay Time";
		};

		class ChargeLabel : AmmunitionLabel
		{
			y           = LABEL_Y + LINE_H*3;
			text        = "Charge Weight";
		};
	};

	class Controls
	{

		class AmmoCombo : vbs3_menu_combo
		{
			idc                = IDC_MORTAR_AMMO;
			x                  = VALUE_X_W;
			y                  = VALUE_Y;
			w                  = VALUE_W_W;
			h                  = VALUE_H;
			onLbSelChanged     = "_this call 'round_selection\updateAmmo.sqf'";
		};

		class FuseCombo : AmmoCombo
		{
			idc                = IDC_MORTAR_FUSE;
			y                  = VALUE_Y + LINE_H;
			onLbSelChanged     = "_this call 'round_selection\updateFuse.sqf'";
		};

		class ProximityDistance : vbs3_menu_edit
		{
			idc                = IDC_MORTAR_PROXIMITY;
			x                  = VALUE_X_W;
			y                  = VALUE_Y + LINE_H*2;
			w                  = GUI_GRID_W * 1.25;
			h                  = VALUE_H;
			text               = "10";
		};

		class FuseTime : ProximityDistance
		{
			idc                = IDC_MORTAR_FUSETIME;
			y                  = VALUE_Y + LINE_H*2;
		};

		class ChargeCombo : AmmoCombo
		{
			idc                = IDC_MORTAR_CHARGE;
			y                  = VALUE_Y + LINE_H*3;
		};

		class OkButton : vbs3_menu_contrastButton
		{
			idc                = IDC_MORTAR_BUTTON_OK;
			x                  = DLG_X_W + DLG_W_W + GUI_GUTTER_W;
			y                  = DLG_Y + TITLE_H;
			w                  = BUTTON_W;
			h                  = BUTTON_H;
			text               = $STR_DISP_OK;
			action             = "_this call 'round_selection\setMortarAmmo.sqf'";
		};

		class CancelButton : OkButton
		{
			idc                = IDC_MORTAR_BUTTON_CANCEL;
			y                  = DLG_Y + TITLE_H + BUTTON_H + GUI_GUTTER_H;
			text               = $STR_DISP_CANCEL;
			action             = closeDialog IDC_MORTAR_BUTTON_CANCEL;
		};
	};
};
