
// Mortar Gunner HUD IDCs
#include "mortar_control\idcsGunner.hpp"

// Round Selection IDCS
#include "round_selection\idcsRoundSelection.hpp"

// Generic/old IDCS
#define IDD_TRAJ_INFO                   90009
#define IDD_MORTAR_OPTIONS              80008

#define IDC_TRAJ_ALT                    99990
#define IDC_TRAJ_TIME                   99991
#define IDC_TRAJ_DIST                   99992
#define IDC_TRAJ_ROUND                  99993
#define IDC_TRAJ_WEIGHT                 99994


