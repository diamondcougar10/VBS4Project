
#define ReadAndWrite 0 //! any modifications enabled
#define ReadAndCreate 1 //! only adding new class members is allowed
#define ReadOnly 2 //! no modifications enabled
#define ReadOnlyVerified 3 //! no modifications enabled, CRC test applied

//---------------------------------
// Control types
//---------------------------------

//2D controls
#define CT_STATIC           0
#define CT_BUTTON           1
#define CT_EDIT             2
#define CT_SLIDER           3
#define CT_COMBO            4
#define CT_LISTBOX          5
#define CT_TOOLBOX          6
#define CT_CHECKBOXES       7
#define CT_PROGRESS         8
#define CT_HTML             9
#define CT_STATIC_SKEW      10
#define CT_ACTIVETEXT       11
#define CT_TREE             12
#define CT_STRUCTURED_TEXT  13
#define CT_CONTEXT_MENU     14
#define CT_CONTROLS_GROUP   15
#define CT_XKEYDESC         40
#define CT_XBUTTON          41
#define CT_XLISTBOX         42
#define CT_XSLIDER          43
#define CT_XCOMBO           44
#define CT_ANIMATED_TEXTURE 45
#define CT_LINEBREAK        98
#define CT_USER             99
#define CT_MAP              100
#define CT_MAP_MAIN         101


//---------------------------------
// Control styles
//---------------------------------

//many of these can be combined; eg: style = ST_RIGHT + ST_SHADOW;

//static styles
#define ST_LEFT           0x00 //left aligned text
#define ST_RIGHT          0x01 //right aligned text
#define ST_CENTER         0x02 //center aligned text
#define ST_HPOS           0x03
#define ST_DOWN           0x04
#define ST_UP             0x08
#define ST_VPOS           0x0C
#define ST_VCENTER        0x0C
#define ST_POS            0x0F

#define ST_TYPE           0xF0
#define ST_SINGLE         0    //single line textbox
#define ST_MULTI          16   //multi-line textbox (text will wrap, and newline character can be used). There is no scrollbar, but mouse wheel/arrows can scroll it. Control will be outlined with a line (color = text color).
#define ST_TITLE_BAR      32
#define ST_PICTURE        48   //turns a static control into a picture control. 'Text' will be used as picture path. Picture will be stretched to fit the control.
#define ST_FRAME          64   //control becomes a frame. Background is clear and text is placed along the top edge of the control. Control is outlined with text color (as in ST_MULTI).
#define ST_BACKGROUND     80
#define ST_GROUP_BOX      96
#define ST_GROUP_BOX2     112
#define ST_HUD_BACKGROUND 128  //control is rounded and outlined (just like a hint box)
#define ST_TILE_PICTURE   144
#define ST_WITH_RECT      160
#define ST_LINE           176  //a line is drawn between the top left and bottom right of the control (color = text color). Background is clear. Control can still have text, however.

#define ST_SHADOW         0x100 //text or image is given a shadow
#define ST_NO_RECT        0x200 //when combined with ST_MULTI, it eliminates the outline around the control. Might combine with other styles for similar effect.
#define ST_KEEP_ASPECT_RATIO  0x800 //used for pictures, it makes the displayed picture keep its aspect ratio.

#define ST_TITLE          ST_TITLE_BAR + ST_CENTER

// Slider styles
#define SL_DIR            0x400
#define SL_VERT           0
#define SL_HORZ           0x400

#define SL_TEXTURES       0x10

// Listbox styles
#define LB_TEXTURES       0x10   //removes all extra lines from listbox, leaving only a gradiant scrollbar. Useful when LB has a painted background behind it.
#define LB_MULTI          0x20   //allows multiple elements of the LB to be selected (by holding shift / ctrl)

//Fonts
#define FontMAIN "TahomaB"

//Main sizes
#define Size_Main_Very_Small 0.018
#define Size_Main_Small 0.027
#define Size_Main_Normal 0.03
#define Size_Main_ToolTip 0.03

//Control sizes
#define Size_Text_Default Size_Main_Normal
#define Size_Text_Very_Small Size_Main_Very_Small
#define Size_Text_Small Size_Main_Small

// Text sizes
#define TextSize_xsmall       1.25*0.014
#define TextSize_IGUI_normal  1.25*0.023
#define TextSize_small        1.25*0.022
#define TextSize_editor       0.020
#define TextSize_normal       1.25*0.024
#define TextSize_medium       1.25*0.027
#define TextSize_large        1.25*0.057


//Base colors
#define Color_Black {0, 0, 0, 1}
#define Color_White {1, 1, 1, 1}
#define Color_WhiteDark {0.85, 0.85, 0.85, 1}
#define Color_Orange {1, 0.5, 0, 1}
#define Color_Gray {0.3, 0.3, 0.3, 1}
#define Color_GrayLight {0.6, 0.6, 0.6, 1}
#define Color_GrayDark {0.2, 0.2, 0.2, 1}
#define VBS2_UI_title_background_semi_transparent {0.9, 0.45, 0, 0.6}

//Colors w/out alpha
#define Black 0, 0, 0
#define Green 0.0, 0.6, 0.0
#define Red 0.7, 0.1, 0.0
#define Yellow 0.8, 0.6, 0.0
#define White 0.8, 0.8, 0.8
#define ShineGreen 0.07, 0.7, 0.2
#define ShineRed 1, 0.2, 0.2
#define ShineYellow 1, 1, 0
#define ShineWhite 1, 1, 1
#define Blue 0.1, 0.1, 0.9
#define Gray1 0.00, 0.00, 0.00
#define Gray2 0.20, 0.20, 0.20
#define Gray3 0.50, 0.50, 0.50
#define Gray4 0.60, 0.60, 0.60
#define Gray5 0.80, 0.80, 0.80

//Main colors
#define Color_Main_Active1 Color_GrayLight
#define Color_Main_Select1 Color_WhiteDark
#define Color_Main_Foreground1 Color_White
#define Color_Main_Background1 Color_Gray
#define Color_Main_Background2 Color_Gray

//Control colors
#define Color_Text_Default Color_Main_Foreground1
#define Color_Text_Orange Color_Main_Foreground1
#define Color_Background Color_Main_Background1
#define Color_Text_White Color_White

//Procedural colors
#define ProcTextWhite "#(argb,8,8,3)color(1,1,1,1)"
#define ProcTextBlack "#(argb,8,8,3)color(0,0,0,1)"
#define ProcTextGray "#(argb,8,8,3)color(0.3,0.3,0.3,1)"
#define ProcTextRed "#(argb,8,8,3)color(1,0,0,1)"
#define ProcTextGreen "#(argb,8,8,3)color(0,1,0,1)"
#define ProcTextBlue "#(argb,8,8,3)color(0,0,1,1)"
#define ProcTextOrange "#(argb,8,8,3)color(1,0.5,0,1)"

//More shades of gray procedural colors commonly used
#define ProcTextGray1 "#(argb,8,8,3)color(0.1,0.1,0.1,1)"
#define ProcTextGray2 "#(argb,8,8,3)color(0.2,0.2,0.2,1)"
#define ProcTextGray3 "#(argb,8,8,3)color(0.3,0.3,0.3,1)"
#define ProcTextGray4 "#(argb,8,8,3)color(0.4,0.4,0.4,1)"
#define ProcTextGray5 "#(argb,8,8,3)color(0.5,0.5,0.5,1)"
#define ProcTextGray6 "#(argb,8,8,3)color(0.6,0.6,0.6,1)"
#define ProcTextGray7 "#(argb,8,8,3)color(0.7,0.7,0.7,1)"
#define ProcTextGray8 "#(argb,8,8,3)color(0.8,0.8,0.8,1)"
#define ProcTextGray9 "#(argb,8,8,3)color(0.9,0.9,0.9,1)"



//Standard static text.
class RscText {
	idc = -1;
	access = ReadAndWrite;
	type = CT_STATIC;
	style = ST_LEFT;
	w = 0.1;
	h = 0.05;

  // text properties
	font = FontMAIN;
	sizeEx = Size_Text_Small;
	colorText[] = Color_Text_Default;
	text = "";

  // background properties
	colorBackground[] = {0, 0, 0, 0};
};


//Standard button.
class RscButton {
	idc = -1;
	access = ReadAndWrite;
	type = CT_BUTTON;
	style = ST_LEFT;
  x = 0;
  y = 0;
	w = 0.3;
	h = 0.1;

  // text properties
  text = "";
  font = FontMAIN;
  sizeEx = TextSize_normal;
  colorText[] = Color_Black;
  colorDisabled[] = Color_Gray;

  // background properties
  colorBackgroundActive[] = Color_Orange;
  colorFocused[] = Color_Orange;
  colorBackground[] = Color_White;
  colorBackgroundDisabled[] = {0.7,0.7,0.7,0.8};
  offsetX = 0.004; // distance of background from shadow
  offsetY = 0.004;
  offsetPressedX = 0.002; // distance of background from shadow when button is pressed
  offsetPressedY = 0.002;

  // shadow properties
  colorShadow[] = {0.72, 0.36, 0, 0.8};
  shadow = 0;

  // border properties
  colorBorder[] = {0.72, 0.36, 0, 0};
  borderSize = 0.008; // when negative, the border is on the right side of background

  // sounds
  soundEnter[] = {"", 0.1, 1};
  soundPush[] = {"", 0.1, 1};
	soundClick[] = {"", 0.1, 1};
	soundEscape[] = {"", 0.1, 1};
};

