The enclosed FSM script (jump.fsm) can be viewed and modified in the FSMEditor.
In order to compile it, the "Compile config" (under "FsmAttributes) should 
point to the file "scriptedFSM.cfg", included in the mission folder.
(This file is NOT needed to run the mission or the FSM script.
It has only been included to allow recompiling in the FSMEditor.)

The script is compatible with both call modes (execFSM & doFSM/commandFSM),
and will interpret the passed argument appropriately.

Its function is as follows:

1) Determine via the available arguments whether it was called via execFSM or not.
2) Read the passed arguments, to determine the usable AI and the destination unit.
3) Order the AI to move towards the destination.
   (Depending on the call type either doMove or moveTo have to be used.)
4) Once the AI is close enough to the destination, it will "jump" 
   (via a setVelocity command), and damages are turned off (otherwise the AI would
   injure itself upon landing).
5) After it has landed, the damage permission is turned back on.
6a) If the FSM was called via doFSM, the script will end.
6b) If it was called via execFSM, it will prompt the player to select a final destination.
7) Once the destination has been set (a user action sets the value via setFSMVariable), 
   the AI is ordered to move there.
8) When the AI has arrived, the FSM is finished.

During the processing of an execFSM'd script, several items are displayed via hint:
* Whether the FSM has finished (checking completedFSM)
* Some internal variables (read with getFSMVariable):
 + _agent: AI unit, as passed in the argument
 + _tgt: Target unit, as passed in the argument
 + _lastMove: String indicating last direction (as set through a user action)
