_getEffectIdx = {
	private ["_type","_properties","_parms","_idx","_xEff"];
	_type = _this select 0;

	_idx = -1;
	for "_i" from 0 to (count Effects)-1 do {
		if (_type==(Effects select _i) select 0) exitWith {
			_idx = _i;
		};
	}forEach Effects;
	_idx
};


// populate the global Effects array with their default values
// which are later updated with the actual slider/button values
/* e.g.
["ChromAberration",
	["relative effect strength - X", 0,1, 0],
	["relative effect strength - Y", 0,1, 0],
	["correction relative to screen ratio", true,false, true]
]
*/	
// if either an effect handle or an array of properties is passed, use those instead
_resetEffArray = {
	private ["_type","_effect","_parms","_properties","_set","_xEff"];
	_type = _this select 0;
	_effect = if (count _this>1) then {_this select 1} else {0};
	_parms = if (count _this>2) then {_this select 2} else {[]};
	
	_properties = [];
	// find the appropritate effect definition in _effectProperties
	{
		if (_type==_x select 0) exitWith {
			_properties = _x;
		};
	}forEach _effectProperties;

	// get the property default values
	for "_i" from 1 to (count _properties)-1 do {
		if (count _parms<_i) then {
			_parms = _parms + [(_properties select _i) select 3];
		};
	};
	// find the matching entry in Effects
	_idx = [_type] call _getEffectIdx;
	if (_idx!=-1) then {
		Effects set [_idx,[_type,_effect,_parms]];
	} else {
		Effects = Effects + [[_type,_effect,_parms]];
	};
	//echo format["[K] reset %1: %2",_properties select 0, _parms];
};


_showSlider = {
	private ["_show","_useSlider","_label","_slider","_button","_pos"];
	_show = _this select 0;
	_useSlider = _this select 1;
	_label = _this select 2;
	_slider = _this select 3;
	_button = _this select 4;
	{
		_pos = ctrlPosition _x;
		_posY = abs(_pos select 1);
		if !(_show) then {
			_posY = _posY * -1;
		};			
		_pos set [1,_posY];
		_x ctrlSetPosition _pos;
		_x ctrlCommit 0;
		_x ctrlShow _show;
	}forEach [_label,_slider,_button];
	_slider ctrlShow _useSlider;
	_button ctrlShow !(_useSlider);
};

// create an effect with the specified parameters, and stores it in a global array
_setEffect = {
	private ["_effect","_effIdx","_effType","_cmdParms"];
	_effect = _this select 0;
	_effIdx = _this select 1;
	_effType = _this select 2;
	_cmdParms = _this select 3;
	_effect ppEffectEnable true;
	_effect ppEffectAdjust _effParms;
	_effect ppEffectCommit 0;
	Effects set [_effIdx,[_effType,_effect,_cmdParms]];
	//echo format["[K] set '%1' (%2) to %3",_effType,_effect,_cmdParms];
};


// read the default assignments for the specified effect type
_getEffDefs = {
	private ["_type","_effDefs","_effectProperty"];
	_type = _this select 0;
	
	// load the selected effect definition from the effects array (for labeling the controls)
	for "_i" from 0 to (count _effectProperties)-1 do {
		_effectProperty = _effectProperties select _i;
		if (_effectProperty select 0==_effType) exitWith {
			_effDefs = _effectProperty;
		};
	}forEach _effectProperties;
	_effDefs
};


// read the slider/button values, and return them as a flat array
_readSliders = {
	private ["_effDefs","_display","_idc","_sliderVals","_ctrlSlider","_ctrlButton","_val"];
	_effDefs = _this select 0;
	_display = _this select 1;
	
	_sliderVals = [];
	for "_i" from 0 to (count _effDefs)-2 do {
		_idc = 20003 + _i*3;
		_ctrlSlider = _display displayCtrl (_idc+1);
		_ctrlButton = _display displayCtrl (_idc+2);
		_val = sliderPosition _ctrlSlider;
		// parameter is boolean (control is active text), so use the true/false caption
		if (typeName ((_effDefs select _i+1) select 1)=="BOOL") then {
			_val = (ctrlText _ctrlButton=="true");
		};
		_sliderVals = _sliderVals + [_val];
	};
	//echo format["[K] %1, %2",count _effDefs,_sliderVals];
	_sliderVals
};


// converts a flat array (e.g. with values from sliders)
// into a nested array, with sub-array appropriate for the effect type
_createCmdArray = {
	private ["_effDefs","_parms","_effParms","_arrDef","_subArr"];
	_effDefs = _this select 0;
	_parms = _this select 1;
	
	_effParms = [];
	_subArr = [];	
	for "_i" from 0 to (count _effDefs)-1 do {
		_val = _parms select _i;
		if (typeName _val=="SCALAR") then {
			_val = [_parms select _i,4] call fn_vbs_cutDecimals;
		};
		// parameter is part of an array, so create a temp array first, 
		// and once the final element has been read, enter it into the argument
		if (count (_effDefs select _i+1)>4) then {
			_arrDef = (_effDefs select _i+1) select 4;
			_subArr set [(_arrDef select 1)-1,_val];
			if (_arrDef select 1==_arrDef select 0) then {
				_effParms = _effParms + [_subArr];
				_subArr = [];
			};
		} else {
			_effParms = _effParms + [_val];
		};
	};
	_effParms
};	
/* used to be this in dialog.sqf:
_subArr = [];	// used to create a temporary array (e.g. for color arrays)
for "_i" from 0 to _defCnt-1 do {
	_idc = 20003 + _i*3;
	_ctrlSlider = _display displayCtrl (_idc+1);
	_ctrlButton = _display displayCtrl (_idc+2);
	_val = [sliderPosition _ctrlSlider,2] call fn_vbs_cutDecimals;
	// parameter is part of an array, so create a temp array first, 
	// and once the final element has been read, enter it into the argument
	if (count (_effDefs select _i+1)>4) then {
		_arrDef = (_effDefs select _i+1) select 4;
		_subArr set [(_arrDef select 1)-1,_val];
		if (_arrDef select 1==_arrDef select 0) then {
			_effParms = _effParms + [_subArr];
			_subArr = [];
		};
	} else {
		// parameter is boolean (control is active text), so use the true/false caption
		if (typeName ((_effDefs select _i+1) select 1)=="BOOL") then {
			_val = (ctrlText _ctrlButton=="true");
		};
		_effParms = _effParms + [_val];
	};
	_sliderVals = _sliderVals + [_val];
};
*/


_getVal = {
	private ["_string","_val"];
	_string = _this select 0;
	_val = parseNumber _tmpVal;
	if (_string=="true") then {
		_val = true;
	};
	if (_string=="false") then {
		_val = false;
	};
	_val
};

// creates an array out of a string, keeping any sub-arrays
_strToArr = {
	private ["_string","_outArr","_tmpArr","_tmpVal","_isArr"];
	_arrArr = toArray _arrstr;
	_outArr = [];
	_tmpArr = [];
	_tmpVal = "";
	_isArr = false;
	for "_i" from 1 to (count _arrArr)-2 do {
		_asc = _arrArr select _i;
		switch (_asc) do {
			// comma
			case 44: {
				if (_tmpval!="") then {
					_val = [_tmpVal] call _getVal;
					if (_isArr) then {
						_tmpArr = _tmpArr + [_val];
					} else {
						_outArr = _outArr + [_val];
						_tmpArr = [];
						_isArr = false;
					};
				};
				_tmpVal = "";
			};
			// bracket open "["
			case 91: {
				_isArr = true;
			};
			// bracket close "]"
			case 93: {
				_val = [_tmpVal] call _getVal;
				_tmpArr = _tmpArr + [_val];
				_outArr = _outArr + [_tmpArr];
				_isArr = false;
				_tmpVal = "";
			};
			default {
				_tmpVal = _tmpVal + toString([_asc]);
			};
		};
	};
	if (_tmpVal!="") then {
		_outArr = _outArr + [[_tmpVal] call _getVal];
	};
	_outArr
};


// creates an array out of a string, making sub-array elements part of the top-level array
_strToArr1 = {
	private ["_string","_outArr","_tmpArr","_tmpVal","_isArr"];
	_arrArr = toArray _arrstr;
	_outArr = [];
	_tmpArr = [];
	_tmpVal = "";
	_isArr = false;
	for "_i" from 1 to (count _arrArr)-2 do {
		_asc = _arrArr select _i;
		switch (_asc) do {
			// space: ignore
			case 32: {};
			// bracket open "[" : ignore
			case 91: {};
			// bracket close "]" : ignore
			case 93: {};
			// comma: store the previously collected digits
			case 44: {
				_val = [_tmpVal] call _getVal;
				_outArr = _outArr + [_val];
				_tmpVal = "";
			};
			// numbers, decimal points : collect until next comma is found
			default {
				_tmpVal = _tmpVal + toString([_asc]);
			};
		};
	};
	if (_tmpVal!="") then {
		_outArr = _outArr + [[_tmpVal] call _getVal];
	};
	_outArr
};