/*
	Effect name
	parameters, range, default, [x,y]: if 4th argument exists then submit as in position y of an array with x elements
	...
	priorities will be assinged in the order the effects are listed here (i.e. the first one will be 1000, next one 900, etc.)
*/
	
_effectProperties = [
	["RadialBlur",
		["blur degree - X", 0,.1, 0],
		["blur degree - Y", 0,.1, 0],
		["size of unblurred center - X", 0,.5, 0],
		["size of unblurred center - Y", 0,.5, 0]
	],

	// http://en.wikipedia.org/wiki/Chromatic_aberration
	["ChromAberration",
		["relative effect strength - X", 0,1, 0],
		["relative effect strength - Y", 0,1, 0],
		["correction relative to screen ratio", true,false, true]
	],

	["WetDistortion",
		["blurriness", 0,1, 0],
		["effect strength - top", 0,1, 0, [2,1]],
		["effect strength - bottom", 0,1, 0, [2,2]],
		["wave speed - x", 0,1, 0, [4,1]],
		["wave speed - y", 0,1, 0, [4,2]],
		["wave speed - z", 0,1, 0, [4,3]],
		["wave speed - ?", 0,1, 0, [4,4]],
		["wave amplitude - x", 0,1, 0, [4,1]],
		["wave amplitude - y", 0,1, 0, [4,2]],
		["wave amplitude - z", 0,1, 0, [4,3]],
		["wave amplitude - ?", 0,1, 0, [4,4]],
		["phase coefficient - x", 0,10, 0, [4,1]],
		["phase coefficient - y", 0,10, 0, [4,2]],
		["phase coefficient - z", 0,10, 0, [4,3]],
		["phase coefficient - ?", 0,10, 0, [4,4]]
	],

	["ColorCorrections",
		["brightness", 0,2, 1],
		["contrast", 0,2, 1],
		["offset", -1,1, 0],
		["blend color - R", -5,5, 0, [4,1]],
		["blend color - G", -5,5, 0, [4,2]],
		["blend color - B", -5,5, 0, [4,3]],
		["blend color - A", -1,1, 0, [4,4]],
		["colorize color - R", -5,5, 1, [4,1]],
		["colorize color - G", -5,5, 1, [4,2]],
		["colorize color - B", -5,5, 1, [4,3]],
		["colorize color - A", -1,1, 1, [4,4]],
		["colorize color - R", -5,5, 1, [4,1]],
		["colorize color - G", -5,5, 1, [4,2]],
		["colorize color - B", -5,5, 1, [4,3]],
		["colorize color - A", -1,1, 1, [4,4]],
		["hole width", 0,1, 0, [7,1]],
		["hole height", 0,1, 0, [7,2]],
		["unknown", 0,1, 0, [7,3]],
		["hole position - x", -1,1, 0, [7,4]],
		["hole position - y", -1,1, 0, [7,5]],
		["edge thickness", 0,1, 1, [7,6]],
		["edge interpolation", -5,5, 1, [7,7]]
	],

	["DynamicBlur",
		["blurriness", 0,20, 0]
	],

	["FilmGrain",
		["intensity", 0,1, 0],
		["sharpness", 0,20, 0],
		["grain size", 1,8, 0],
		["intensityX0", 0,5, 0],
		["intensityX1", 0,5, 0],
		["monochromatic", true,false, true]
	],

	["ColorInversion",
		["Inversion channel - Red", 0,1, 0],
		["Inversion channel - Green", 0,1, 0],
		["Inversion channel - Blue", 0,1, 0]
	]

];