class CfgPatches {
	class KRON_MissionSwitcher {
		units[]={};
		weapons[]={};
		requiredVersion=1.0;
	};
};



//Standard static text
class RscText {
	idc = -1;
	access = 0;
	type = 0;
	style = 0;
	w = 0.1;
	h = 0.05;
	font = "TahomaB";
	sizeEx = 0.027;
	colorBackground[] = {0, 0, 0, 0};
	colorText[] = {1, 1, 1, 1};
	text = "";
	autoScrollSpeed = -1;
	autoScrollDelay = 5;
	autoScrollRewind = false;
	arrowEmpty = "#(argb,8,8,3)color(1,1,1,1)";
	arrowFull = "#(argb,8,8,3)color(1,1,1,1)";
	shadow = 0;
	class ScrollBar { 
		color[] = {1,1,1,0.6}; 
		colorActive[] = {1,1,1,1}; 
		colorDisabled[] = {1,1,1,0.3}; 
  	thumb = "#(argb,8,8,3)color(1,1,1,1)";
  	arrowEmpty = "#(argb,8,8,3)color(1,1,1,1)";
  	arrowFull = "#(argb,8,8,3)color(1,1,1,1)";
  	border = "#(argb,8,8,3)color(1,1,1,1)";
    shadow = 0;
	};		
	colorSelect[] = {0, 0, 0, 1};
	rowHeight = 0;
	maxHistoryDelay = 1.0; 
	soundSelect[] = {"", 0.1, 1};
	linespacing = 1;
};



class KRON_SwitcherDlg {
  idd = 20000;
  movingEnable = true;
  
  class controls {
		class HEADER : RscText {
			idc = 20000;
			style = 16; // ST_MULTI
	  	x = .3;
	  	y = .2;
	  	w = .4;
	  	h = .1;
		};
	};

	class controlsBackground {
	  class FORM_BACKGROUND : RscText {
	  	moving = 1;
	  	x = .28;
	  	y = .18;
	  	w = .44;
	  	h = .14;
			colorBackground[] = {0.8, 0.8, 0.8, 0.8};
	  };
	};
};
