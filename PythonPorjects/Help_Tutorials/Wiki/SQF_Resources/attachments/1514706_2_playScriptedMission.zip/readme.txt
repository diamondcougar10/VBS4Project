Contains the sources, and packed version, of a mission switcher addon,
to be used with playScriptedMission.


To try out the addon, place the file "missionswitcher.pbo" into your 
mycontent\addons folder, and start any mission (or editor preview).

In this mission, execute the following command 
(either via a user action, radio trigger, or any other suited method):

playScriptedMission ['intro',{[1] execVM 'vbs2\kron\missionSwitcher\data\scripts\init.sqf'},missionConfigFile,true];

This will load the Rahmadi map, and spawn the player, as well as some other characters,
in the town center.

Once this scripted mission has been loaded, the user can then jump to any of the other two
missions by using the radio calls (0-0-1, 0-0-2 or 0-0-3).


When packing your own addon, the sources (folder MissionSwitcher) should be copied to 
where you would normally pack your addons from, 
and the addon's class name (in config.cpp>>CfgPatches) should be adjusted, to match
your normally used naming conventions.