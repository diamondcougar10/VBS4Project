_adjustDialog = {
	private ["_display"];
	_display  = _this select 0;
	
	_back0Ctrl = _display displayCtrl IDC_BACK_ALL;
	_back1Ctrl = _display displayCtrl IDC_BACK_SEL;
	_back2Ctrl = _display displayCtrl IDC_BACK_TEX;
	
	_unitTxtCtrl = _display displayCtrl IDC_UNITTYPE_TXT;
	
	_selTxtCtrl = _display displayCtrl IDC_SELECTIONS_TXT;
	_selLBCtrl = _display displayCtrl IDC_SELECTIONS_LB;
	
	_texTxtCtrl = _display displayCtrl IDC_TEXTURES_TXT;
	_texLBCtrl = _display displayCtrl IDC_TEXTURES_LB;
	
	_pasteTxtCtrl  = _display displayCtrl IDC_PASTE_EDT;
	_applyBtnCtrl = _display displayCtrl IDC_APPLY_BTN;
	_resetBtnCtrl = _display displayCtrl IDC_RESET_BTN;
	
	
	// adjust dialog size & position, depending on aspect ratio
	_ratio = aspectRatio;
	
	_ytop = .1;
	_xleft = .01;     
	_width = .4;              
	_height = .605;
	_heightLB = .2;
	
	// 4:3=1,.075, 16:9=1.3333,0.75, 16:10=1.2,0.75
	_xratio = _ratio select 0;
	if (_xratio>1) then {
		_xleft = ((_xratio-1)/2)*-1;     
		_width = _xratio/3;
	};
	_widthLB = _width-.01;
	
	_back0Ctrl    ctrlSetPosition [_xleft, _ytop, _width, _height]; 
	_back1Ctrl    ctrlSetPosition [_xleft+.005, _ytop+.03+.04, _widthLB, _heightLB]; 
	_back2Ctrl    ctrlSetPosition [_xleft+.005, _ytop+.03+.04+_heightLB+.04, _widthLB, _heightLB];
	
	_y = _ytop;
	_unitTxtCtrl  ctrlSetPosition [_xleft, _y, _widthLB, .03]; _y = _y + .04;
	_selTxtCtrl   ctrlSetPosition [_xleft, _y, _widthLB, .03]; _y = _y + .03;
	_selLBCtrl    ctrlSetPosition [_xleft, _y, _widthLB, _heightLB]; _y = _y + _heightLB+.01;
	
	_texTxtCtrl   ctrlSetPosition [_xleft, _y, _widthLB, .03]; _y = _y + .03;
	_texLBCtrl    ctrlSetPosition [_xleft, _y, _widthLB, _heightLB]; _y = _y + _heightLB +.01;
	
	_pasteTxtCtrl ctrlSetPosition [_xleft+.005, _y, _widthLB, .03]; _y = _y + .04;
	
	_resetBtnCtrl ctrlSetPosition [_xleft+.01, _y, _width/2-.02, .03];
	_applyBtnCtrl ctrlSetPosition [_xleft+_width/2+.01, _y, _width/2-.02, .03];
	
	{_x ctrlCommit 0}forEach [_back0Ctrl,_back1Ctrl,_back2Ctrl,_unitTxtCtrl,_selTxtCtrl,_selLBCtrl,_texTxtCtrl,_texLBCtrl,_pasteTxtCtrl,_applyBtnCtrl,_resetBtnCtrl];  
};


// updates the toolTip for the textures listbox
fn_showTexture = {
	private ["_idx","_currTexture"];
	_idx = (_this select 0) lbPosIndex [_this select 1,_this select 2];
	_currTexture = (_this select 0) lbText _idx;

	if (_idx>-1) then {
		_currTexture = '""';
		if (_idx>0) then {
			// special texture selection [default]
			_currTexture = "#reset";
			if (_idx>1) then {
				// special texture selection [procedural color]
				_currTexture = PROCCOLOR;
				if (_idx>2) then {
					// otherwise use the regular texture that was selected
					_currTexture = (_this select 0) lbText _idx;
					if (trim [_currTexture,0,(strlen _currTexture)-1]=="(") then {
						_currTexture = format["%1 (possible mismatch)",trim[_currTexture,1,1]];
					};
				};
			};
		};
		(_this select 0) ctrlSetTooltip _currTexture;
	};
};