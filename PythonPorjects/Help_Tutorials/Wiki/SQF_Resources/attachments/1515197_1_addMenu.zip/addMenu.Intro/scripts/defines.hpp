// positions to use as destination
#define LOCATIONS [ ["Beach",[3490,2394]], ["Town",[2883,2869]], ["Runway",[2511,2460]] ]

// find the associtated position for a destination name
_getPos = {
	private ["_dest","_pos"];
	_dest = _this select 0;
	_pos = [0,0];
	{
		if (_x select 0==_dest) exitWith {
			_pos = _x select 1;
		};
	}forEach LOCATIONS;
	_pos
};