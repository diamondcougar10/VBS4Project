To use the example RTT objects (sign & car, under "VBS2 Objects"), place the enclosed PBO into your \mycontent\addons folder.

To use the example mission, place the RTTDemo.Intro folder into you MPmission folder, and open it in the editor.

The sources for the example objects can be seen in the RTTDemo folder.
To modify and recompile it, place it into the following folder: p:\vbs2\Demo\RTTDemo