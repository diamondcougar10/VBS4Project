// basic defines
#include "\vbs2\customer\defines.hpp"

#define __CurrentDir__ \vbs2\Demo\RTTDemo

class CfgPatches
{
	class RTT_Demo
	{
		units[]={};
		weapons[]={};
		requiredVersion=1.0;
	};
};

class CfgVehicles {

	// Demo Sign
	class vbs2_fence;
	class rtt_demo_sign : vbs2_fence {
		scope        = public;
		vehicleClass = VBS2_Objects;
		displayname  = "RTT Demo Sign";
		model        = __CurrentDir__\sign;
		preview      = __CurrentDir__\data\ico\preview_sign_ca;
	};

	// Demo Vehicle
	class VBS2_M1114_BASE;
	class rtt_demo_car : VBS2_M1114_BASE
	{
		scope        = 2;
		vehicleClass = VBS2_Objects;
		displayName  = "RTT Demo Car";
		model        = __CurrentDir__\rttcar;
		driverAction = "vbs2_bushmaster_Driver";
	};

};